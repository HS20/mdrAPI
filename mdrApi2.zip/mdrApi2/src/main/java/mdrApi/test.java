package mdrApi;

import java.net.MalformedURLException;
import java.net.URL;

import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import mdrApi.Service.codeValueManager;
import mdrApi.generatedDAO.MdrPermissibleValueDAO;
import mdrApi.generatedDomain.MdrPermissibleValue;

public class test {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		
		System.out.println("data " + new codeValueManager().deCodeCode("DXC|REPONSE:4855-4855|1009").get("idDataElement"));
		System.out.println("prefix " +new codeValueManager().deCodeCode("DXC|REPONSE:4855-4855|1009").get("prefix"));
		System.out.println("perm " +new codeValueManager().deCodeCode("DXC|REPONSE:4855-4855|1009").get("idPermissible"));
		
		System.out.println("data " +new codeValueManager().deCodeCode("SYN|ANA:CGZ2").get("idDataElement"));
		System.out.println("prefix " +new codeValueManager().deCodeCode("SYN|ANA:CGZ2").get("prefix"));
		System.out.println("perm " +new codeValueManager().deCodeCode("SYN|ANA:CGZ2").get("idPermissible"));
		

		String endPoint=new URL("http", "sim1dev", 8889, "/bigdata").toExternalForm();
		String namespace="semanticRepository";
		BlazeGraphClient client = new BlazeGraphClient(endPoint, namespace,false);

		//client.getRdf4jClient().deleteGraph(graph);
//		MdrPermissibleValue permV=new MdrPermissibleValue("http://test#ok");
//		permV.addLabel("Ok Lab");
//		
//		new MdrPermissibleValueDAO(client).write(permV);
//		
//		client.close();
	}
	

}
