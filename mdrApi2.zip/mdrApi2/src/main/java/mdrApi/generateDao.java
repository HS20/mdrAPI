package mdrApi;

import org.semanticweb.owlapi.model.OWLOntologyCreationException;

import generateJavaClass.service.DAOGenerator;



public class generateDao {

	public static void main(String[] args) throws OWLOntologyCreationException {
		// TODO Auto-generated method stub
		String file="src/main/resources/mdrhsv2.rdf";
		new DAOGenerator().generateDAO(file, "mdr",".","mdrApi");
	}

}
