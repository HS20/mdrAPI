package mdrApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;
import org.eclipse.rdf4j.model.Model;
import org.eclipse.rdf4j.model.Resource;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.rio.Rio;
import org.eclipse.rdf4j.rio.UnsupportedRDFormatException;
import org.openrdf.repository.RepositoryException;
import org.openrdf.rio.RDFParseException;
import org.openrdf.sail.rdbms.algebra.factories.URIExprFactory;

import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import chu_bordeaux.org.ClientRDF4J.BlazegraphImportClient;


public class initRepository {

	protected static final Logger log = Logger.getLogger(initRepository.class);
	
	public static void main(String[] args) throws org.eclipse.rdf4j.rio.RDFParseException, UnsupportedRDFormatException, IOException {
		// TODO Auto-generated method stub
		
		String endPoint =new URL("http", "sim1dev.chu-bordeaux.fr",8889,"/bigdata").toExternalForm();
		String namespace="mdrHadrien";
		BlazeGraphClient client = new BlazeGraphClient(endPoint, namespace,false);
	
		String file="src/main/resources/mdrhs.rdf";
		File owlFile=new File(file);
		
		client.getRdf4jClient().clearRepository();
		String context="http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl";
//		String mimetype="application/rdf+xml";
		FileInputStream in=new FileInputStream(owlFile);
		
//		ModelBuilder builder = new ModelBuilder();
		 
//		builder.namedGraph("http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl");
		
//		Model model=Rio.parse(in, "", RDFFormat.RDFXML);
	
		client.getRdf4jClient().getConnection().add(in,"",RDFFormat.RDFXML,SimpleValueFactory.getInstance().createIRI(context));
		
		client.close();
	}

}
