package mdrApi.Service;

import java.io.IOException;
import java.text.Normalizer;
import java.util.HashMap;

import org.apache.commons.collections.map.HashedMap;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class codeValueManager {

	public final static String DXCREPONSE="DXC|REPONSE";
	public final static String DXCQUESTION="DXC|QUESTION";
	public final static String DXCQUESTIONAUTRE="DXC|QUESTION|AUTRE";
	public final static String DXCQUESTIONBLOB="DXC|QUESTION|BLOB";
	public final static String ICD10="ICD10";
	public final static String ICDOMORPHO="ICDO_MORPHO";
	public final static String ADM="ADM";
	public final static String PRESC="PRESC";
	public final static String PMSI="PMSI";
	public final static String TK="TK";
	public final static String SYNERGIE="SYN|ANA";
	public final static String DOCUMENT="DOC";
	public final static String DIAMIC="DIAMIC";
	public final static String DIAMIC_ADICAP="DIAMIC|ADICAP";
	public final static String ICD10CHU="ICD10CHU";
	public final static String CCAM="CCAM";
	
	public final static String DATAELEMENTID_PMSI_DIAGNOSTIC="DIAGNOSIC";
	public final static String DATAELEMENTID_PMSI_ACTE="ACTE";
	
	public final static String DATAELEMENTID_PRESC_DRUG="DRUG_PRESC";
	public final static String DATAELEMENTID_ADM_DRUG="DRUG_ADM";
	public final static String DATAELEMENTID_ADM_QTE="QUANTITE";
	public final static String VALUEDOMAIN_PRESC_DRUG="DRUG_VALUEDOMAIN";
	
	public final static String DATAELEMENTID_ADICAP="ADICAP";
	public final static String DATAELEMENTID_ADICAP_LESION="LESION";
	public final static String DATAELEMENTID_ADICAP_ORGANE="ORGANE";
	public final static String DATAELEMENTID_ADICAP_MODPREL="MODPREL";
	public final static String DATAELEMENTID_ADICAP_TYPTECH="TYPTECH";
	
	public final static String DATAELEMENTID_TK_MALADIE_ICD10="TK_MALADIE_ICD10";
	public final static String DATAELEMENTID_TK_STATUT="TK_STATUT";
	public final static String DATAELEMENTID_TK_TYPE_CONSENT="TK_TYPE_CONSENT";
	public final static String DATAELEMENTID_TK_NOM_BANQUE="TK_NOM_BANQUE";
	public final static String DATAELEMENTID_TK_TNM_PT="TK_TNM_PT";
	public final static String DATAELEMENTID_TK_TNM_PN="TK_TNM_PN";
	public final static String DATAELEMENTID_TK_TNM_PM="TK_TNM_PM";
	public final static String DATAELEMENTID_TK_TNM_CT="TK_TNM_CT";
	public final static String DATAELEMENTID_TK_TNM_CN="TK_TNM_CN";
	public final static String DATAELEMENTID_TK_TNM_CM="TK_TNM_CM";
	public final static String DATAELEMENTID_TK_GRADE="TK_GRADE";
	public final static String DATAELEMENTID_TK_TYPE_ECHANTILLON="TK_TYPE_ECHANTILLON";
	public final static String DATAELEMENTID_TK_CATEGORIE="TK_CATEGORIE";
//	public final static String DATAELEMENTID_TK|DIAGNOSTIC:ADICAP="TK|DIAGNOSTIC:ADICAP";
//	public final static String DATAELEMENTID_TK|DIAGNOSTIC:ADICAP="TK:ADICAP-LESION";
//	public final static String DATAELEMENTID_TK|DIAGNOSTIC:ADICAP="TK:ADICAP-ORGANE";
	
	
	
	
	
	 /**
     * manageCode: returns Code.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("prefix") input: The prefix of the code to be generated (usually) a partitionName.
     * {param} string("dataElementID") input: The prefix of the code to be generated (usually) a partitionName.     * 
     * {param} string("permissibleID") input: The prefix of the code to be generated (usually) a partitionName.
     * {param} string("alternateID") input: The prefix of the code to be generated (usually) a partitionName.
     * {example} manageCode("DXC|REPONSE",10,1,null).
     */
    public static String manageCode(String prefix,String dataElementID, String valueDomainId,String permissibleID,String alternateID) {
        String code=null;
        
        dataElementID=formatId(dataElementID);
         if (valueDomainId!=null){
        	 valueDomainId=formatId(valueDomainId);
        }
         
        if (permissibleID!=null){
        	permissibleID=formatId(permissibleID);
        }
        if (alternateID!=null){
        	alternateID=formatId(alternateID);
        }
        
//        System.out.println(prefix);
//        System.out.println(dataElementID);
//        System.out.println(permissibleID);
//        System.out.println(alternateID);
    	switch(prefix){
    		case DXCREPONSE :
    			if(alternateID==null){
    				code=prefix+":"+dataElementID.trim()+"-"+valueDomainId.trim()+"|"+permissibleID.trim();
//    			}else{
//    				code=prefix+"|ICD10CHU:"+dataElementID.trim()+"-"+permissibleID.trim();
//    			}
    				
    			}else {
    				code=prefix+":"+dataElementID.trim()+"-"+ICD10CHU+"|"+formatCodeForICD10CHU(alternateID);
    			}
//    			}else if (alternateID.trim().length()==6 & alternateID.substring(0, 1).equals("M")) {
//    				code=prefix+ICDOMORPHO+":"+dataElementID.trim()+"-"+alternateID.substring(0, 5)+"/"+alternateID.substring(5, 6);
//    			}else if (alternateID.length()>3){
//    				code=prefix+ICD10+":"+dataElementID.trim()+"-"+alternateID.substring(0, 3)+"."+alternateID.substring(3, alternateID.trim().length());
//    			}else{
//    				code=prefix+ICD10+":"+dataElementID.trim()+"-"+alternateID.trim();
//    			}
    			break;
    			
    		case PMSI :
//    			if(alternateID==null){
//    				code=prefix+":"+dataElementID.trim()+"-"+permissibleID.trim();
//    			}else{
//    				code=prefix+"|ICD10CHU:"+dataElementID.trim()+"-"+permissibleID.trim();
//    			}
    			if(dataElementID.equals(DATAELEMENTID_PMSI_DIAGNOSTIC)){
    				code=prefix+":"+dataElementID.trim()+"-"+ICD10CHU+"|"+formatCodeForICD10CHU(permissibleID);
//    				if (permissibleID.trim().length()==6 & permissibleID.substring(0, 1).equals("M")) {
//    					code=prefix+ICDOMORPHO+":"+dataElementID.trim()+"-"+permissibleID.substring(0, 5)+"/"+permissibleID.substring(5, 6);
//    				}else if (alternateID.length()>3){
//    					code=prefix+ICD10+":"+dataElementID.trim()+"-"+permissibleID.substring(0, 3)+"."+permissibleID.substring(3, permissibleID.trim().length());
//    				}else{
//    					code=prefix+ICD10+":"+dataElementID.trim()+"-"+permissibleID.trim();
//    				}
    				break;
    			}
//    		case "DXC|QUESTION|BLOB" :
//    			code=prefix+":"+dataElementID.trim();
//    			break;    		
//    		case "DXC|QUESTION|AUTRE" :
//    			code=prefix+":"+dataElementID.trim();
//    			break;
    			
     		default :
    			if (permissibleID==null){
    				code=prefix+":"+dataElementID.trim();
    			}else{
    				code=prefix+":"+dataElementID.trim()+"-"+valueDomainId.trim()+"|"+permissibleID.trim();
    			}
    			break;  		
    	}
    	
    	return code;
    }
    
    /**
     * formatId: returns a formated String for an ID.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("ID") input: The ID to format
     * {example} formatId("DXC-20") ==> DXC_20.
     */
    
    public static String formatId(String id){
    	return Normalizer.normalize(id, Normalizer.Form.NFD)
    			.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "")
    			.toUpperCase()
    			.trim()
    			.replaceAll("[^A-Z0-9\\-*]", "_");
    }
    
    /**
     * getPrefixForICD10CHU: returns a formated prefix for an ICD10 code.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("code") input: The code to for which to find the prefix
     * {example} getPrefixForICD10CHU("C50.2").
     */
    
    public static String getPrefixForICD10CHU(String code){
    	String prefix;
    	if (code.trim().length()==6 & code.substring(0, 1).equals("M")) {
			prefix=ICDOMORPHO;
		}else if (code.length()>3){
			prefix=ICD10;
		}else{
			prefix=ICD10;
		}
    	return prefix;
    }
    
    /**
     * formatCodeForICD10CHU: returns a formated code for an ICD10 code.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("code") input: The code to format
     * {example} formatCodeForICD10CHU("C50.2").
     */
    
    public static String formatCodeForICD10CHU(String code){
    	
		if (code.trim().length()==6 & code.substring(0, 1).equals("M")) {
			code=code.substring(0, 5)+"/"+code.substring(5, 6);
		}else if (code.length()>3){
			code=code.substring(0, 3)+"."+code.substring(3, code.trim().length());
		}else{
			code=code.trim();
		}
				
    	return code;
    }
    
    /**
     * formatIDADICAP: returns a formated code for an ICD10 code.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("code") input: The code to format
     * {param} string("idValueDomain") input: The valueDomain ID
     * {example} formatIDADICAP("A7A0","LESION").
     */
    
    public static String formatCodeWithValueDomain(String prefix, String idValueDomain,String code){
    	
    	code=prefix+"|"+idValueDomain+":"+code;
		return code;
    }
    
    /**
     * deCodeCode: returns HashMap (idDataElement, idPermissible, prefix).
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("code") input: The code to decode in DataElement / permissible
     * {example} deCodeCode("DXC|REPONSE:10-1").
     */
    
    public static HashMap<String,String> deCodeCode(String code) {
    	HashMap<String,String> decode=new HashMap<String, String>();
    	
    	String idDataElement=null;
    	String idPermissible=null;
    	
    	
    	if (!code.contains(":")){
    		throw new RuntimeException("Code non conforme" + code);
    	}
    	
    	String prefix=code.split(":")[0];
    	String content=code.split(":")[1];
		
    	if (code.contains("-")){
    		idDataElement=content.split("-")[0].trim();
    		if(content.split("-").length>1){
    			idPermissible=content.split("-")[1].trim();
    		}
    	}else{
    		idDataElement=content;
    	}
    	
    	if(idPermissible!=null){
    		idPermissible=prefix+":"+idPermissible;
    	}
    	
    	switch (prefix) {
		case DXCREPONSE+ICD10:
			idDataElement=DXCQUESTION+":"+idDataElement;
			break;
		case DXCREPONSE:
			idDataElement=DXCQUESTION+":"+idDataElement;
			break;
		case DXCREPONSE+ICDOMORPHO:
			idDataElement=DXCQUESTION+":"+idDataElement;
			break;
		case DXCQUESTIONAUTRE:
			idDataElement=DXCQUESTION+":"+idDataElement;
			break;
		case DXCQUESTIONBLOB:
			idDataElement=DXCQUESTION+":"+idDataElement;
			break;
				
		default:
			idDataElement=prefix+":"+idDataElement;
			break;
		}
    	
    	decode.put("prefix", prefix);
    	decode.put("idDataElement", idDataElement);
    	decode.put("idPermissible", idPermissible);
    	
        return decode;
    }
    
    /**
     * getIdDataElement: returns a dataElement identifier.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("prefix") input: the prefix (i2b2 prefix)
     * {param} string("dataElement") dataElement identifier in the source
     * {example} getIdDataElement("DXC|QUESTION|AUTRE","52483").
     */
    
    public static String getIdDataElement(String prefix, String dataElement) {
    	String idDataElement;
    	
    	dataElement=formatId(dataElement);
    	
    	switch (prefix) {
		case DXCREPONSE:
			idDataElement=DXCQUESTION+":"+dataElement;
			break;
		case DXCQUESTIONAUTRE:
			idDataElement=DXCQUESTION+":"+dataElement;
			break;
		case DXCQUESTIONBLOB:
			idDataElement=DXCQUESTION+":"+dataElement;
			break;
				
		default:
			idDataElement=prefix+":"+dataElement;
			break;
		}
    	
        return idDataElement;
    }
    
    /**
     * getIdValueDomain: returns a prefixed valueDomain identifier.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("prefix") input: the prefix (i2b2 prefix)
     * {param} string("valueDomain") valueDomain identifier in the source
     * {example} getIdDataElement("DXC|QUESTION|AUTRE","52483").
     */
    
    public static String getIdValueDomain(String prefix, String valueDomain) {
    	String idValueDomain;
    	
    	valueDomain=formatId(valueDomain);
    	switch (prefix) {
		case DXCREPONSE:
			idValueDomain=DXCQUESTION+":"+valueDomain;
			break;
		case DXCQUESTIONAUTRE:
			idValueDomain=DXCQUESTION+":"+valueDomain;
			break;
		case DXCQUESTIONBLOB:
			idValueDomain=DXCQUESTION+":"+valueDomain;
			break;
		case DXCQUESTION:
			if(valueDomain.equals("-1000")){
				idValueDomain=ICD10CHU;
			}else{
				idValueDomain=DXCQUESTION+":"+valueDomain;
			}
			break;		
		default:
			idValueDomain=prefix+":"+valueDomain;
			break;
		}
    	
        return idValueDomain;
    }
    
    /**
     * getIdPermissibleValue: returns a prefixed permissibleValue identifier.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("prefix") input: the prefix (i2b2 prefix)
     * {param} string("valueDomain") valueDomain identifier in the source
     * {param} string("permissibleValue") valueDomain identifier in the source
     * {example} getIdDataElement("DXC|QUESTION|AUTRE","52483","52485").
     */
    
    public static String getIdPermissibleValue(String prefix, String valueDomain,String permissibleValue,String code) {
    	String idPermissibleValue;
    	
    	valueDomain=formatId(valueDomain);
    	permissibleValue=formatId(permissibleValue);
    	
    	switch (prefix) {
    	case DXCREPONSE:
    		if(valueDomain.equals("-1000")){
    			idPermissibleValue=prefix+":"+ICD10CHU+"|"+formatCodeForICD10CHU(code);
    		}else{
    			idPermissibleValue=prefix+":"+valueDomain+"|"+permissibleValue;
    		}
    		break;
		default:
			idPermissibleValue=prefix+":"+valueDomain+"|"+permissibleValue;
			break;
		}
    	
        return idPermissibleValue;
    }
    
}
