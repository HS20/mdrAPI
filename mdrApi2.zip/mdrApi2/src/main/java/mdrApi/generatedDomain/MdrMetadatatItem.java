package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrMetadatatItem extends MdrThing {
	protected static final Logger log = Logger.getLogger(MdrMetadatatItem.class);

	public MdrMetadatatItem(String uri) {
		super(uri);
		initMdrMetadatatItem();

	}
	public MdrMetadatatItem(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrMetadatatItem";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrMetadatatItem();

	}
	public MdrMetadatatItem() {
		super();
		initMdrMetadatatItem();

	}




	protected void initMdrMetadatatItem() { 
	} 

}
