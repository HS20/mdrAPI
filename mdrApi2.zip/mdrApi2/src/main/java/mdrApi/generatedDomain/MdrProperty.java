package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrProperty extends MdrAdministeredItem {
	protected static final Logger log = Logger.getLogger(MdrProperty.class);

	public MdrProperty(String uri) {
		super(uri);
		initMdrProperty();

	}
	public MdrProperty(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrProperty";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrProperty();

	}
	public MdrProperty() {
		super();
		initMdrProperty();

	}




	protected void initMdrProperty() { 
	} 

}
