package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrDesignation extends MdrMetadatatItem {
	protected static final Logger log = Logger.getLogger(MdrDesignation.class);
	private Set<String> sign;

	public MdrDesignation(String uri) {
		super(uri);
		initMdrDesignation();

	}
	public MdrDesignation(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrDesignation";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrDesignation();

	}
	public MdrDesignation() {
		super();
		initMdrDesignation();

	}




	@Getter
	public Set<String> getSign() {
		return this.sign;
 
	} 

	@Setter(simple=false,nomAttribut="sign")
	public void addAllSign(Set<String> sign) {
		this.sign.addAll(sign);
 
	} 

	@Setter(simple=true,nomAttribut="sign")
	public void addSign(String sign) {
		if(!(sign==null)){
			this.sign.add(sign);
		}
 
	} 

	public boolean hasSign() {
		return this.sign.size()>0;
 
	} 

	protected void initMdrDesignation() {
		this.sign=new HashSet<String>(); 
	} 

}
