package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrValueMeaning extends MdrAttachedItem {
	protected static final Logger log = Logger.getLogger(MdrValueMeaning.class);

	public MdrValueMeaning(String uri) {
		super(uri);
		initMdrValueMeaning();

	}
	public MdrValueMeaning(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrValueMeaning";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrValueMeaning();

	}
	public MdrValueMeaning() {
		super();
		initMdrValueMeaning();

	}




	protected void initMdrValueMeaning() { 
	} 

}
