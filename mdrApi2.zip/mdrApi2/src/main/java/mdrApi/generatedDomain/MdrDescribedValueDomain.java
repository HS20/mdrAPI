package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrDescribedValueDomain extends MdrValueDomain {
	protected static final Logger log = Logger.getLogger(MdrDescribedValueDomain.class);

	public MdrDescribedValueDomain(String uri) {
		super(uri);
		initMdrDescribedValueDomain();

	}
	public MdrDescribedValueDomain(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrDescribedValueDomain";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrDescribedValueDomain();

	}
	public MdrDescribedValueDomain() {
		super();
		initMdrDescribedValueDomain();

	}




	protected void initMdrDescribedValueDomain() { 
	} 

}
