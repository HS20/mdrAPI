package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrEnumeratedValueDomain extends MdrValueDomain {
	protected static final Logger log = Logger.getLogger(MdrEnumeratedValueDomain.class);

	public MdrEnumeratedValueDomain(String uri) {
		super(uri);
		initMdrEnumeratedValueDomain();

	}
	public MdrEnumeratedValueDomain(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrEnumeratedValueDomain";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrEnumeratedValueDomain();

	}
	public MdrEnumeratedValueDomain() {
		super();
		initMdrEnumeratedValueDomain();

	}




	protected void initMdrEnumeratedValueDomain() { 
	} 

}
