package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrIdentifiedItem extends MdrMetadatatItem {
	protected static final Logger log = Logger.getLogger(MdrIdentifiedItem.class);

	public MdrIdentifiedItem(String uri) {
		super(uri);
		initMdrIdentifiedItem();

	}
	public MdrIdentifiedItem(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrIdentifiedItem";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrIdentifiedItem();

	}
	public MdrIdentifiedItem() {
		super();
		initMdrIdentifiedItem();

	}




	protected void initMdrIdentifiedItem() { 
	} 

}
