package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrValueDomain extends MdrAdministeredItem {
	protected static final Logger log = Logger.getLogger(MdrValueDomain.class);
	private Set<String> unitOfMeasure;
	private Set<String> dataType;
	private Set<String> format;
	private Set<String> maximumCharacterQuantity;

	public MdrValueDomain(String uri) {
		super(uri);
		initMdrValueDomain();

	}
	public MdrValueDomain(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrValueDomain";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrValueDomain();

	}
	public MdrValueDomain() {
		super();
		initMdrValueDomain();

	}




	@Getter
	public Set<String> getUnitOfMeasure() {
		return this.unitOfMeasure;
 
	} 

	@Setter(simple=false,nomAttribut="unitOfMeasure")
	public void addAllUnitOfMeasure(Set<String> unitOfMeasure) {
		this.unitOfMeasure.addAll(unitOfMeasure);
 
	} 

	@Setter(simple=true,nomAttribut="unitOfMeasure")
	public void addUnitOfMeasure(String unitOfMeasure) {
		if(!(unitOfMeasure==null)){
			this.unitOfMeasure.add(unitOfMeasure);
		}
 
	} 

	public boolean hasUnitOfMeasure() {
		return this.unitOfMeasure.size()>0;
 
	} 

	@Getter
	public Set<String> getDataType() {
		return this.dataType;
 
	} 

	@Setter(simple=false,nomAttribut="dataType")
	public void addAllDataType(Set<String> dataType) {
		this.dataType.addAll(dataType);
 
	} 

	@Setter(simple=true,nomAttribut="dataType")
	public void addDataType(String dataType) {
		if(!(dataType==null)){
			this.dataType.add(dataType);
		}
 
	} 

	public boolean hasDataType() {
		return this.dataType.size()>0;
 
	} 

	@Getter
	public Set<String> getFormat() {
		return this.format;
 
	} 

	@Setter(simple=false,nomAttribut="format")
	public void addAllFormat(Set<String> format) {
		this.format.addAll(format);
 
	} 

	@Setter(simple=true,nomAttribut="format")
	public void addFormat(String format) {
		if(!(format==null)){
			this.format.add(format);
		}
 
	} 

	public boolean hasFormat() {
		return this.format.size()>0;
 
	} 

	@Getter
	public Set<String> getMaximumCharacterQuantity() {
		return this.maximumCharacterQuantity;
 
	} 

	@Setter(simple=false,nomAttribut="maximumCharacterQuantity")
	public void addAllMaximumCharacterQuantity(Set<String> maximumCharacterQuantity) {
		this.maximumCharacterQuantity.addAll(maximumCharacterQuantity);
 
	} 

	@Setter(simple=true,nomAttribut="maximumCharacterQuantity")
	public void addMaximumCharacterQuantity(String maximumCharacterQuantity) {
		if(!(maximumCharacterQuantity==null)){
			this.maximumCharacterQuantity.add(maximumCharacterQuantity);
		}
 
	} 

	public boolean hasMaximumCharacterQuantity() {
		return this.maximumCharacterQuantity.size()>0;
 
	} 

	protected void initMdrValueDomain() {
		this.unitOfMeasure=new HashSet<String>();
		this.dataType=new HashSet<String>();
		this.format=new HashSet<String>();
		this.maximumCharacterQuantity=new HashSet<String>(); 
	} 

}
