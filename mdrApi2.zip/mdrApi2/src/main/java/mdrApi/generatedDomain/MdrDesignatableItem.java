package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrDesignatableItem extends MdrMetadatatItem {
	protected static final Logger log = Logger.getLogger(MdrDesignatableItem.class);

	public MdrDesignatableItem(String uri) {
		super(uri);
		initMdrDesignatableItem();

	}
	public MdrDesignatableItem(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrDesignatableItem";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrDesignatableItem();

	}
	public MdrDesignatableItem() {
		super();
		initMdrDesignatableItem();

	}




	protected void initMdrDesignatableItem() { 
	} 

}
