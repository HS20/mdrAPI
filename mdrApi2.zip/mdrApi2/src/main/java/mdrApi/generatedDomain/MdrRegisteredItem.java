package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrRegisteredItem extends MdrIdentifiedItem {
	protected static final Logger log = Logger.getLogger(MdrRegisteredItem.class);

	public MdrRegisteredItem(String uri) {
		super(uri);
		initMdrRegisteredItem();

	}
	public MdrRegisteredItem(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrRegisteredItem";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrRegisteredItem();

	}
	public MdrRegisteredItem() {
		super();
		initMdrRegisteredItem();

	}




	protected void initMdrRegisteredItem() { 
	} 

}
