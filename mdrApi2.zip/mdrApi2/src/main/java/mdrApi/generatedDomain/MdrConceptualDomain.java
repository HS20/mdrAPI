package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrConceptualDomain extends MdrAdministeredItem {
	protected static final Logger log = Logger.getLogger(MdrConceptualDomain.class);
	private Set<String> dimensionality;

	public MdrConceptualDomain(String uri) {
		super(uri);
		initMdrConceptualDomain();

	}
	public MdrConceptualDomain(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrConceptualDomain";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrConceptualDomain();

	}
	public MdrConceptualDomain() {
		super();
		initMdrConceptualDomain();

	}




	@Getter
	public Set<String> getDimensionality() {
		return this.dimensionality;
 
	} 

	@Setter(simple=false,nomAttribut="dimensionality")
	public void addAllDimensionality(Set<String> dimensionality) {
		this.dimensionality.addAll(dimensionality);
 
	} 

	@Setter(simple=true,nomAttribut="dimensionality")
	public void addDimensionality(String dimensionality) {
		if(!(dimensionality==null)){
			this.dimensionality.add(dimensionality);
		}
 
	} 

	public boolean hasDimensionality() {
		return this.dimensionality.size()>0;
 
	} 

	protected void initMdrConceptualDomain() {
		this.dimensionality=new HashSet<String>(); 
	} 

}
