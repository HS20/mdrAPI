package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrDefinition extends MdrMetadatatItem {
	protected static final Logger log = Logger.getLogger(MdrDefinition.class);
	private Set<String> text;

	public MdrDefinition(String uri) {
		super(uri);
		initMdrDefinition();

	}
	public MdrDefinition(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrDefinition";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrDefinition();

	}
	public MdrDefinition() {
		super();
		initMdrDefinition();

	}




	@Getter
	public Set<String> getText() {
		return this.text;
 
	} 

	@Setter(simple=false,nomAttribut="text")
	public void addAllText(Set<String> text) {
		this.text.addAll(text);
 
	} 

	@Setter(simple=true,nomAttribut="text")
	public void addText(String text) {
		if(!(text==null)){
			this.text.add(text);
		}
 
	} 

	public boolean hasText() {
		return this.text.size()>0;
 
	} 

	protected void initMdrDefinition() {
		this.text=new HashSet<String>(); 
	} 

}
