package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrPermissibleValue extends MdrMappableRelationshipItem {
	protected static final Logger log = Logger.getLogger(MdrPermissibleValue.class);
	private Set<String> permittedValue;

	public MdrPermissibleValue(String uri) {
		super(uri);
		initMdrPermissibleValue();

	}
	public MdrPermissibleValue(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrPermissibleValue";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrPermissibleValue();

	}
	public MdrPermissibleValue() {
		super();
		initMdrPermissibleValue();

	}




	@Getter
	public Set<String> getPermittedValue() {
		return this.permittedValue;
 
	} 

	@Setter(simple=false,nomAttribut="permittedValue")
	public void addAllPermittedValue(Set<String> permittedValue) {
		this.permittedValue.addAll(permittedValue);
 
	} 

	@Setter(simple=true,nomAttribut="permittedValue")
	public void addPermittedValue(String permittedValue) {
		if(!(permittedValue==null)){
			this.permittedValue.add(permittedValue);
		}
 
	} 

	public boolean hasPermittedValue() {
		return this.permittedValue.size()>0;
 
	} 

	protected void initMdrPermissibleValue() {
		this.permittedValue=new HashSet<String>(); 
	} 

}
