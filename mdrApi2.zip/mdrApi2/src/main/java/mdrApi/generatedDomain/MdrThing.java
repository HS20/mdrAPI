package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;
import generateJavaClass.domain.AvailableService;

public class MdrThing {
	protected static final Logger log = Logger.getLogger(MdrThing.class);
	private Set<String> comment;
	protected IRI uri;
	private Set<String> label;
	private Set<IRI> type;
	private Set<AvailableService> availableServices;

	public MdrThing(String uri) {
		this.uri=new IRIManager().setIRIFromString(uri);
		initMdrThing();

	}
	public MdrThing(String nameSpace,String localName,boolean hash) {
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrThing();

	}
	public MdrThing() {
		initMdrThing();

	}




	@Getter
	public Set<String> getComment() {
		return this.comment;
 
	} 

	@Setter(simple=false,nomAttribut="comment")
	public void addAllComment(Set<String> comment) {
		this.comment.addAll(comment);
 
	} 

	@Setter(simple=true,nomAttribut="comment")
	public void addComment(String comment) {
		if(!(comment==null)){
			this.comment.add(comment);
		}
 
	} 

	public boolean hasComment() {
		return this.comment.size()>0;
 
	} 

	@Getter
	public IRI getUri() {
		return this.uri;
 
	} 

	@Setter(simple=true,nomAttribut="uri")
	public void setUri(IRI uri) {		
this.uri=uri;
 
	} 

	public boolean hasUri() {
		return !(this.uri== null);
 
	} 

	@Getter
	public Set<String> getLabel() {
		return this.label;
 
	} 

	@Setter(simple=false,nomAttribut="label")
	public void addAllLabel(Set<String> label) {
		this.label.addAll(label);
 
	} 

	@Setter(simple=true,nomAttribut="label")
	public void addLabel(String label) {
		if(!(label==null)){
			this.label.add(label);
		}
 
	} 

	public boolean hasLabel() {
		return this.label.size()>0;
 
	} 

	@Getter
	public Set<IRI> getType() {
		return this.type;
 
	} 

	@Setter(simple=false,nomAttribut="type")
	public void addAllType(Set<IRI> type) {
		this.type.addAll(type);
 
	} 

	@Setter(simple=true,nomAttribut="type")
	public void addType(IRI type) {
		if(!(type==null)){
			this.type.add(type);
		}
 
	} 

	public boolean hasType() {
		return this.type.size()>0;
 
	} 

	public void setUriFromString(String uri) {		this.uri=SimpleValueFactory.getInstance().createIRI(uri); 
	} 

	public void addAvailableServices(AvailableService availableServices) {
		if(!(availableServices==null)){
			this.availableServices.add(availableServices);
		}
 
	} 

	public void addAllAvailableServices(Set<AvailableService> availableServices) {
		this.availableServices.addAll(availableServices);
 
	} 

	public Set<AvailableService> getAvailableServices() {
		return this.availableServices;
 
	} 

	protected void initMdrThing() {
		this.comment=new HashSet<String>();
		this.label=new HashSet<String>();
		this.type=new HashSet<IRI>();
		this.availableServices=new HashSet<AvailableService>(); 
	} 

}
