package mdrApi.generatedDomain;


import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import java.util.HashSet;
import java.util.Set;
import generateJavaClass.annotations.Setter;
import generateJavaClass.annotations.Getter;
import generateJavaClass.service.IRIManager;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;

public class MdrDataElement extends MdrThing {
	protected static final Logger log = Logger.getLogger(MdrDataElement.class);
	private Set<String> precision;

	public MdrDataElement(String uri) {
		super(uri);
		initMdrDataElement();

	}
	public MdrDataElement(String nameSpace,String localName,boolean hash) {
		super();
		nameSpace+="/MdrDataElement";
		try { 
				this.uri=new IRIManager().setIRIFromString(nameSpace,localName,hash);
			} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block 
				e.printStackTrace();
			}
		initMdrDataElement();

	}
	public MdrDataElement() {
		super();
		initMdrDataElement();

	}




	@Getter
	public Set<String> getPrecision() {
		return this.precision;
 
	} 

	@Setter(simple=false,nomAttribut="precision")
	public void addAllPrecision(Set<String> precision) {
		this.precision.addAll(precision);
 
	} 

	@Setter(simple=true,nomAttribut="precision")
	public void addPrecision(String precision) {
		if(!(precision==null)){
			this.precision.add(precision);
		}
 
	} 

	public boolean hasPrecision() {
		return this.precision.size()>0;
 
	} 

	protected void initMdrDataElement() {
		this.precision=new HashSet<String>(); 
	} 

}
