package mdrApi.generatedDAO;


import org.apache.log4j.Logger;
import java.util.Set;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import org.eclipse.rdf4j.query.BindingSet;
import java.util.List;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import mdrApi.generatedVocabulary.MDRVOCABULARY;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.IRI;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.lang.reflect.InvocationTargetException;
import generateJavaClass.service.Binder;
import org.eclipse.rdf4j.model.ValueFactory;
import org.eclipse.rdf4j.model.impl.SimpleValueFactory;
import generateJavaClass.domain.BaseDAO;
import org.eclipse.rdf4j.repository.RepositoryConnection;
import mdrApi.generatedDomain.MdrThing;

public class MdrThingDAO {
	protected static final Logger log = Logger.getLogger(MdrThingDAO.class);
	private String selectRead = " ?type ?uri  ?comment  ?label  ";
	private String whereRead = "   ?uri a ?type . \n ?uri a "+MDRVOCABULARY.ThingSparql+" . \n OPTIONAL {?uri "+MDRVOCABULARY.commentSparql+" ?comment . } \n  OPTIONAL {?uri "+MDRVOCABULARY.labelSparql+" ?label . } \n  ";
	protected BlazeGraphClient client;
	protected Binder binder;
	protected ValueFactory valueFactory;

	public MdrThingDAO(BlazeGraphClient client) {
		this.client=client;
		this.binder=new Binder(this);
		this.valueFactory=SimpleValueFactory.getInstance();

	}




	public MdrThing readMdrThing(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrThing> domains = new HashMap<IRI,MdrThing>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" \n where { BIND (<" + uri + "> as ?uri) \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrThing domain = new MdrThing();
					domain = (MdrThing) new Binder(new MdrThing()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrThing domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().findFirst().get();
 
	} 

	public Set<MdrThing> readAllMdrThing() throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrThing> domains = new HashMap<IRI,MdrThing>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrThing domain = new MdrThing();
					domain = (MdrThing) new Binder(new MdrThing()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrThing domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrThing> readAllMdrThing(StringBuilder filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrThing> domains = new HashMap<IRI,MdrThing>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  " + filter.toString() + " " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrThing domain = new MdrThing();
					domain = (MdrThing) new Binder(new MdrThing()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrThing domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	/**
	* builds and writes  RDF4J Model based on a RDF4J ModelBuilder to a repository. Statements will be inserted to the default context  
	* @param builder the RDF4J ModelBuilder to build and insert
	*/


	public void addToRepo(ModelBuilder builder) {
		addToRepo(builder,null); 
	} 

	/**
	* builds and writes  RDF4J Model based on a RDF4J ModelBuilder to a repository in a specified context
	* @param builder the RDF4J ModelBuilder to build and insert
	* @param graph The graph to write into
	*/


	public void addToRepo(ModelBuilder builder,String graph) {
		RepositoryConnection conn = client.getRdf4jClient().getConnection();
		if (graph==null){
			conn.add(builder.build());
		}else{
			IRI iriContext=valueFactory.createIRI(graph);
			conn.add(builder.build(),iriContext);
		}
		conn.close(); 
	} 

	/**
	* writes a MdrThing definition to a repository statements will be written in the default graph
	* @param domain a MdrThing = the class to be added
	*/


	public void write(MdrThing domain) {
		write(domain,null); 
	} 

	/**
	* writes a MdrThing definition to a repository in a specified graph 
	* @param domain a MdrThing = the class to be added
	* @param graph the graph into which statements will be written
	*/


	public void write(MdrThing domain,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilder(builder,domain);
		addToRepo(builder,graph); 
	} 

	/**
	* adds a MdrThing definition to a rdf4j ModelBuilder 
	* @param builder the rdf4j ModelBuilder to feed
	* @param domain a MdrThing = the class to be added
	*/


	public ModelBuilder addToBuilder(ModelBuilder builder,MdrThing domain) {
		builder.subject(domain.getUri().toString());
		if (domain.hasComment()){
				domain.getComment().forEach( x -> {
					builder.add(MDRVOCABULARY.comment, x);
			});
		}
		if (domain.hasLabel()){
				domain.getLabel().forEach( x -> {
					builder.add(MDRVOCABULARY.label, x);
			});
		}
		builder.add(RDF.TYPE, MDRVOCABULARY.Thing);
		return builder; 
	} 

}
