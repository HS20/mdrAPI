package mdrApi.generatedDAO;


import org.apache.log4j.Logger;
import java.util.Set;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import org.eclipse.rdf4j.query.BindingSet;
import java.util.List;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import mdrApi.generatedVocabulary.MDRVOCABULARY;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.IRI;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.lang.reflect.InvocationTargetException;
import generateJavaClass.service.Binder;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.util.HashSet;
import mdrApi.generatedDomain.MdrProperty;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrDescribedValueDomain;
import mdrApi.generatedDomain.MdrObjectClass;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrDescribedConceptualDomain;
import mdrApi.generatedDomain.MdrIdentifiedItem;
import mdrApi.generatedDomain.MdrRegisteredItem;
import mdrApi.generatedDomain.MdrEnumeratedValueDomain;
import mdrApi.generatedDomain.MdrDesignatableItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrEnumeratedConceptualDomain;

public class MdrDataElementDAO extends MdrThingDAO {
	protected static final Logger log = Logger.getLogger(MdrDataElementDAO.class);
	private String selectRead = " ?type ?uri  ?precision  ?comment  ?label  ";
	private String whereRead = "   ?uri a ?type . \n ?uri a "+MDRVOCABULARY.DataElementSparql+" . \n OPTIONAL {?uri "+MDRVOCABULARY.precisionSparql+" ?precision . } \n  OPTIONAL {?uri "+MDRVOCABULARY.commentSparql+" ?comment . } \n  OPTIONAL {?uri "+MDRVOCABULARY.labelSparql+" ?label . } \n  ";

	public MdrDataElementDAO(BlazeGraphClient client) {
		super(client);

	}




	public MdrDataElement readMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" \n where { BIND (<" + uri + "> as ?uri) \n ?uri a "+MDRVOCABULARY.DataElementSparql+" . \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().findFirst().get();
 
	} 

	public Set<MdrDataElement> readAllMdrDataElement() throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  ?uri a "+MDRVOCABULARY.DataElementSparql+" . \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> readAllMdrDataElement(StringBuilder filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  ?uri a "+MDRVOCABULARY.DataElementSparql+" . \n " + filter.toString() + " " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	/**
	* writes a MdrDataElement definition to a repository statements will be written in the default graph
	* @param domain a MdrDataElement = the class to be added
	*/


	public void write(MdrDataElement domain) {
		write(domain,null); 
	} 

	/**
	* writes a MdrDataElement definition to a repository in a specified graph 
	* @param domain a MdrDataElement = the class to be added
	* @param graph the graph into which statements will be written
	*/


	public void write(MdrDataElement domain,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilder(builder,domain);
		addToRepo(builder,graph); 
	} 

	/**
	* adds a MdrDataElement definition to a rdf4j ModelBuilder 
	* @param builder the rdf4j ModelBuilder to feed
	* @param domain a MdrDataElement = the class to be added
	*/


	public ModelBuilder addToBuilder(ModelBuilder builder,MdrDataElement domain) {
		builder.subject(domain.getUri().toString());
		if (domain.hasPrecision()){
				domain.getPrecision().forEach( x -> {
					builder.add(MDRVOCABULARY.precision, x);
			});
		}
		if (domain.hasComment()){
				domain.getComment().forEach( x -> {
					builder.add(MDRVOCABULARY.comment, x);
			});
		}
		if (domain.hasLabel()){
				domain.getLabel().forEach( x -> {
					builder.add(MDRVOCABULARY.label, x);
			});
		}
		builder.add(RDF.TYPE, MDRVOCABULARY.DataElement);
		return builder; 
	} 

	/**
	* writes a RepresentsDataElementMeaning relation between a MdrDataElement and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeRepresentsDataElementMeaning(MdrDataElement aDomain,MdrDataElementConcept aRange) {
 		writeRepresentsDataElementMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a RepresentsDataElementMeaning relation between a MdrDataElement and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeRepresentsDataElementMeaning(MdrDataElement aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderRepresentsDataElementMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a RepresentsDataElementMeaning relation between a MdrDataElement and a MdrDataElementConcept
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderRepresentsDataElementMeaning(MdrDataElement aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.representsDataElementMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesMeaningForDataElementMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContextin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContextin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContext
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignationin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignation
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClassin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClass
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinitionin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinition
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElement
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValue
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConcept
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPropertyin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrProperty
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaningin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaning
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ProvidesValuesForDataElementDomain relation between a MdrValueDomain and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeProvidesValuesForDataElementDomain(MdrValueDomain aDomain,MdrDataElement aRange) {
 		writeProvidesValuesForDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a ProvidesValuesForDataElementDomain relation between a MdrValueDomain and a MdrDataElementin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeProvidesValuesForDataElementDomain(MdrValueDomain aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderProvidesValuesForDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ProvidesValuesForDataElementDomain relation between a MdrValueDomain and a MdrDataElement
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderProvidesValuesForDataElementDomain(MdrValueDomain aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrDataElement aRange) {
 		writeHasPossibleTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrDataElement
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange) {
 		writeHasPossibleTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange) {
 		writeHasPossibleTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrPermissibleValue
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange) {
 		writeHasPossibleTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleTarget relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleTarget(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrDescribedValueDomain aRange) {
 		writeUsesDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementDomain relation between a MdrDataElement and a MdrDescribedValueDomain
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementDomain(MdrDataElement aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsesDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementDomain relation between a MdrDataElement and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementDomain(MdrDataElement aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrValueDomain aRange) {
 		writeUsesDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrValueDomainin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementDomain relation between a MdrDataElement and a MdrValueDomain
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementDomain(MdrDataElement aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange) {
 		writeHasDefinitionItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinitionin the repository 
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasDefinitionItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinition
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a IsComponentOf relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeIsComponentOf(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange) {
 		writeIsComponentOf(aDomain,aRange,null); 
	} 

	/**
	* writes a IsComponentOf relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeIsComponentOf(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderIsComponentOf(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a IsComponentOf relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderIsComponentOf(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.isComponentOf, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.composedOf, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ProvidesMeaningForDataElementMeaning relation between a MdrDataElementConcept and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeProvidesMeaningForDataElementMeaning(MdrDataElementConcept aDomain,MdrDataElement aRange) {
 		writeProvidesMeaningForDataElementMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a ProvidesMeaningForDataElementMeaning relation between a MdrDataElementConcept and a MdrDataElementin the repository 
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeProvidesMeaningForDataElementMeaning(MdrDataElementConcept aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderProvidesMeaningForDataElementMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ProvidesMeaningForDataElementMeaning relation between a MdrDataElementConcept and a MdrDataElement
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderProvidesMeaningForDataElementMeaning(MdrDataElementConcept aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.providesMeaningForDataElementMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.representsDataElementMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContextin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContextin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContext
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignationin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignation
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClassin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClass
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinitionin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinition
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElement
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValue
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConcept
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPropertyin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrProperty
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaningin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaning
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange) {
 		writeHasDesignationItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignationin the repository 
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasDesignationItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignation
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrDataElement aRange) {
 		writeComposedOf(aDomain,aRange,null); 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrDataElementin the repository 
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderComposedOf(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ComposedOf relation between a MdrCompositeInformationItem and a MdrDataElement
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderComposedOf(MdrCompositeInformationItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.composedOf, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.isComponentOf, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrCompositeInformationItem aRange) {
 		writeComposedOf(aDomain,aRange,null); 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderComposedOf(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ComposedOf relation between a MdrCompositeInformationItem and a MdrCompositeInformationItem
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderComposedOf(MdrCompositeInformationItem aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.composedOf, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.isComponentOf, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrPermissibleValue aRange) {
 		writeComposedOf(aDomain,aRange,null); 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderComposedOf(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ComposedOf relation between a MdrCompositeInformationItem and a MdrPermissibleValue
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderComposedOf(MdrCompositeInformationItem aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.composedOf, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.isComponentOf, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrMappableRelationshipItem aRange) {
 		writeComposedOf(aDomain,aRange,null); 
	} 

	/**
	* writes a ComposedOf relation between a MdrCompositeInformationItem and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeComposedOf(MdrCompositeInformationItem aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderComposedOf(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ComposedOf relation between a MdrCompositeInformationItem and a MdrMappableRelationshipItem
	* @param aDomain a MdrCompositeInformationItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderComposedOf(MdrCompositeInformationItem aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.composedOf, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.isComponentOf, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrDataElement aRange) {
 		writeHasSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasSource relation between a MdrMappableRelationshipItem and a MdrDataElement
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasSource(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange) {
 		writeHasSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasSource relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasSource(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange) {
 		writeHasSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasSource relation between a MdrMappableRelationshipItem and a MdrPermissibleValue
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasSource(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange) {
 		writeHasSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasSource relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasSource(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasSource relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasSource(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElement
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItem
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClassin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClass
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConcept
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrPropertyin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrProperty
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrDataElement aRange) {
 		writeHasPossibleSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrDataElement
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange) {
 		writeHasPossibleSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange) {
 		writeHasPossibleSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrPermissibleValue
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange) {
 		writeHasPossibleSource(aDomain,aRange,null); 
	} 

	/**
	* writes a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasPossibleSource(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasPossibleSource relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasPossibleSource(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasPossibleSource, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrDataElement aRange) {
 		writeHasTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrDataElementin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasTarget relation between a MdrMappableRelationshipItem and a MdrDataElement
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasTarget(MdrMappableRelationshipItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange) {
 		writeHasTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasTarget relation between a MdrMappableRelationshipItem and a MdrCompositeInformationItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasTarget(MdrMappableRelationshipItem aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange) {
 		writeHasTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasTarget relation between a MdrMappableRelationshipItem and a MdrPermissibleValue
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasTarget(MdrMappableRelationshipItem aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasTarget, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange) {
 		writeHasTarget(aDomain,aRange,null); 
	} 

	/**
	* writes a HasTarget relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasTarget(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasTarget(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasTarget relation between a MdrMappableRelationshipItem and a MdrMappableRelationshipItem
	* @param aDomain a MdrMappableRelationshipItem = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasTarget(MdrMappableRelationshipItem aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasTarget, aRange.getUri());
		return builder; 
	} 

	public Set<MdrDataElement> findMdrDataElementByRepresentsDataElementMeaning(MdrDataElementConcept filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.representsDataElementMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByRepresentsDataElementMeaningMdrDataElementConcept(Set<MdrDataElementConcept> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByRepresentsDataElementMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseUsedForItemItemDefinition(MdrDefinition filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usedForItemItemDefinition>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseUsedForItemItemDefinitionMdrDefinition(Set<MdrDefinition> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByInverseUsedForItemItemDefinition(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseProvidesValuesForDataElementDomain(MdrValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#providesValuesForDataElementDomain>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseProvidesValuesForDataElementDomainMdrValueDomain(Set<MdrValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByInverseProvidesValuesForDataElementDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTarget(MdrPermissibleValue filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTargetMdrPermissibleValue(Set<MdrPermissibleValue> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTarget(MdrDataElement filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTargetMdrDataElement(Set<MdrDataElement> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTarget(MdrCompositeInformationItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTargetMdrCompositeInformationItem(Set<MdrCompositeInformationItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTarget(MdrMappableRelationshipItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleTargetMdrMappableRelationshipItem(Set<MdrMappableRelationshipItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByUsesDataElementDomain(MdrDescribedValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.usesDataElementDomainSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByUsesDataElementDomainMdrDescribedValueDomain(Set<MdrDescribedValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByUsesDataElementDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByUsesDataElementDomain(MdrEnumeratedValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.usesDataElementDomainSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByUsesDataElementDomainMdrEnumeratedValueDomain(Set<MdrEnumeratedValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByUsesDataElementDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByUsesDataElementDomain(MdrValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.usesDataElementDomainSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByUsesDataElementDomainMdrValueDomain(Set<MdrValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByUsesDataElementDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasDefinitionItemDefinition(MdrDefinition filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasDefinitionItemDefinitionSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasDefinitionItemDefinitionMdrDefinition(Set<MdrDefinition> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasDefinitionItemDefinition(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByIsComponentOf(MdrCompositeInformationItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.isComponentOfSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByIsComponentOfMdrCompositeInformationItem(Set<MdrCompositeInformationItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByIsComponentOf(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseProvidesMeaningForDataElementMeaning(MdrDataElementConcept filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#providesMeaningForDataElementMeaning>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseProvidesMeaningForDataElementMeaningMdrDataElementConcept(Set<MdrDataElementConcept> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByInverseProvidesMeaningForDataElementMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseUsedForItemItemDesignation(MdrDesignation filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usedForItemItemDesignation>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseUsedForItemItemDesignationMdrDesignation(Set<MdrDesignation> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByInverseUsedForItemItemDesignation(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasDesignationItemDesignation(MdrDesignation filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasDesignationItemDesignationSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasDesignationItemDesignationMdrDesignation(Set<MdrDesignation> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasDesignationItemDesignation(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseComposedOf(MdrCompositeInformationItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#composedOf>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseComposedOfMdrCompositeInformationItem(Set<MdrCompositeInformationItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByInverseComposedOf(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSource(MdrPermissibleValue filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSourceMdrPermissibleValue(Set<MdrPermissibleValue> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSource(MdrDataElement filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSourceMdrDataElement(Set<MdrDataElement> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSource(MdrCompositeInformationItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSourceMdrCompositeInformationItem(Set<MdrCompositeInformationItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSource(MdrMappableRelationshipItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasSourceMdrMappableRelationshipItem(Set<MdrMappableRelationshipItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseAttachedToAttachment(MdrAttachedItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#attachedToAttachment>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByInverseAttachedToAttachmentMdrAttachedItem(Set<MdrAttachedItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByInverseAttachedToAttachment(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSource(MdrPermissibleValue filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSourceMdrPermissibleValue(Set<MdrPermissibleValue> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSource(MdrDataElement filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSourceMdrDataElement(Set<MdrDataElement> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSource(MdrCompositeInformationItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSourceMdrCompositeInformationItem(Set<MdrCompositeInformationItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSource(MdrMappableRelationshipItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasPossibleSourceSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasPossibleSourceMdrMappableRelationshipItem(Set<MdrMappableRelationshipItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasPossibleSource(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTarget(MdrPermissibleValue filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTargetMdrPermissibleValue(Set<MdrPermissibleValue> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTarget(MdrDataElement filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTargetMdrDataElement(Set<MdrDataElement> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTarget(MdrCompositeInformationItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTargetMdrCompositeInformationItem(Set<MdrCompositeInformationItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTarget(MdrMappableRelationshipItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrDataElement> domains = new HashMap<IRI,MdrDataElement>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasTargetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrDataElement domain = new MdrDataElement();
					domain = (MdrDataElement) new Binder(new MdrDataElement()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrDataElement domain2=domains.get(domain.getUri());
							domain.addAllPrecision(domain2.getPrecision());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrDataElement> findMdrDataElementByHasTargetMdrMappableRelationshipItem(Set<MdrMappableRelationshipItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrDataElement> result = new HashSet<MdrDataElement>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrDataElementByHasTarget(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

}
