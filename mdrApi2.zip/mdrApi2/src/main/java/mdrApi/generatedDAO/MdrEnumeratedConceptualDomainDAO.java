package mdrApi.generatedDAO;


import org.apache.log4j.Logger;
import java.util.Set;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import org.eclipse.rdf4j.query.BindingSet;
import java.util.List;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import mdrApi.generatedVocabulary.MDRVOCABULARY;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.IRI;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.lang.reflect.InvocationTargetException;
import generateJavaClass.service.Binder;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrEnumeratedConceptualDomain;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import java.util.HashSet;
import mdrApi.generatedDomain.MdrProperty;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrDescribedValueDomain;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrObjectClass;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrDescribedConceptualDomain;
import mdrApi.generatedDomain.MdrIdentifiedItem;
import mdrApi.generatedDomain.MdrRegisteredItem;
import mdrApi.generatedDomain.MdrEnumeratedValueDomain;
import mdrApi.generatedDomain.MdrDesignatableItem;
import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;

public class MdrEnumeratedConceptualDomainDAO extends MdrConceptualDomainDAO {
	protected static final Logger log = Logger.getLogger(MdrEnumeratedConceptualDomainDAO.class);
	private String selectRead = " ?type ?uri  ?dimensionality  ?comment  ?label  ";
	private String whereRead = "   ?uri a ?type . \n ?uri a "+MDRVOCABULARY.EnumeratedConceptualDomainSparql+" . \n OPTIONAL {?uri "+MDRVOCABULARY.dimensionalitySparql+" ?dimensionality . } \n  OPTIONAL {?uri "+MDRVOCABULARY.commentSparql+" ?comment . } \n  OPTIONAL {?uri "+MDRVOCABULARY.labelSparql+" ?label . } \n  ";

	public MdrEnumeratedConceptualDomainDAO(BlazeGraphClient client) {
		super(client);

	}




	public MdrEnumeratedConceptualDomain readMdrEnumeratedConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" \n where { BIND (<" + uri + "> as ?uri) \n ?uri a "+MDRVOCABULARY.EnumeratedConceptualDomainSparql+" . \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().findFirst().get();
 
	} 

	public Set<MdrEnumeratedConceptualDomain> readAllMdrEnumeratedConceptualDomain() throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  ?uri a "+MDRVOCABULARY.EnumeratedConceptualDomainSparql+" . \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> readAllMdrEnumeratedConceptualDomain(StringBuilder filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  ?uri a "+MDRVOCABULARY.EnumeratedConceptualDomainSparql+" . \n " + filter.toString() + " " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	/**
	* writes a MdrEnumeratedConceptualDomain definition to a repository statements will be written in the default graph
	* @param domain a MdrEnumeratedConceptualDomain = the class to be added
	*/


	public void write(MdrEnumeratedConceptualDomain domain) {
		write(domain,null); 
	} 

	/**
	* writes a MdrEnumeratedConceptualDomain definition to a repository in a specified graph 
	* @param domain a MdrEnumeratedConceptualDomain = the class to be added
	* @param graph the graph into which statements will be written
	*/


	public void write(MdrEnumeratedConceptualDomain domain,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilder(builder,domain);
		addToRepo(builder,graph); 
	} 

	/**
	* adds a MdrEnumeratedConceptualDomain definition to a rdf4j ModelBuilder 
	* @param builder the rdf4j ModelBuilder to feed
	* @param domain a MdrEnumeratedConceptualDomain = the class to be added
	*/


	public ModelBuilder addToBuilder(ModelBuilder builder,MdrEnumeratedConceptualDomain domain) {
		builder.subject(domain.getUri().toString());
		if (domain.hasDimensionality()){
				domain.getDimensionality().forEach( x -> {
					builder.add(MDRVOCABULARY.dimensionality, x);
			});
		}
		if (domain.hasComment()){
				domain.getComment().forEach( x -> {
					builder.add(MDRVOCABULARY.comment, x);
			});
		}
		if (domain.hasLabel()){
				domain.getLabel().forEach( x -> {
					builder.add(MDRVOCABULARY.label, x);
			});
		}
		builder.add(RDF.TYPE, MDRVOCABULARY.EnumeratedConceptualDomain);
		return builder; 
	} 

	/**
	* writes a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange) {
 		writeHasDefinitionItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinitionin the repository 
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasDefinitionItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinition
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrDescribedConceptualDomain aRange) {
 		writeHasMeaningValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMeaningValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrDescribedConceptualDomain
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeHasMeaningValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMeaningValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrConceptualDomain aRange) {
 		writeHasMeaningValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMeaningValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrConceptualDomain
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrDescribedValueDomain aRange) {
 		writeHasRepresentionValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasRepresentionValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrDescribedValueDomain
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrEnumeratedValueDomain aRange) {
 		writeHasRepresentionValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasRepresentionValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrEnumeratedValueDomain
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrValueDomain aRange) {
 		writeHasRepresentionValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrValueDomainin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasRepresentionValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrValueDomain
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsesDataElementConceptDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementConceptDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementConceptDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesDomainForDataElementConceptDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsesDataElementConceptDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementConceptDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementConceptDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesDomainForDataElementConceptDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrConceptualDomain aRange) {
 		writeUsesDataElementConceptDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementConceptDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementConceptDomain relation between a MdrDataElementConcept and a MdrConceptualDomain
	* @param aDomain a MdrDataElementConcept = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementConceptDomain(MdrDataElementConcept aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementConceptDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesDomainForDataElementConceptDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMemberValueMeaningSet relation between a MdrEnumeratedConceptualDomain and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrEnumeratedConceptualDomain = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeHasMemberValueMeaningSet(MdrEnumeratedConceptualDomain aDomain,MdrValueMeaning aRange) {
 		writeHasMemberValueMeaningSet(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMemberValueMeaningSet relation between a MdrEnumeratedConceptualDomain and a MdrValueMeaningin the repository 
	* @param aDomain a MdrEnumeratedConceptualDomain = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMemberValueMeaningSet(MdrEnumeratedConceptualDomain aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMemberValueMeaningSet(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMemberValueMeaningSet relation between a MdrEnumeratedConceptualDomain and a MdrValueMeaning
	* @param aDomain a MdrEnumeratedConceptualDomain = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMemberValueMeaningSet(MdrEnumeratedConceptualDomain aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMemberValueMeaningSet, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.containedInValueMeaningSet, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContextin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContextin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContext
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignationin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignation
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClassin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClass
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinitionin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinition
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElement
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValue
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConcept
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPropertyin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrProperty
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaningin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaning
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContextin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContextin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContext
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignationin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignation
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClassin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClass
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinitionin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinition
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElement
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValue
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConcept
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPropertyin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrProperty
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaningin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaning
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange) {
 		writeHasDesignationItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignationin the repository 
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasDesignationItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignation
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElement
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItem
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClassin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClass
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConcept
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrPropertyin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrProperty
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a ProvidesDomainForDataElementConceptDomain relation between a MdrConceptualDomain and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeProvidesDomainForDataElementConceptDomain(MdrConceptualDomain aDomain,MdrDataElementConcept aRange) {
 		writeProvidesDomainForDataElementConceptDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a ProvidesDomainForDataElementConceptDomain relation between a MdrConceptualDomain and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeProvidesDomainForDataElementConceptDomain(MdrConceptualDomain aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderProvidesDomainForDataElementConceptDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ProvidesDomainForDataElementConceptDomain relation between a MdrConceptualDomain and a MdrDataElementConcept
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderProvidesDomainForDataElementConceptDomain(MdrConceptualDomain aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.providesDomainForDataElementConceptDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementConceptDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ContainedInValueMeaningSet relation between a MdrValueMeaning and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueMeaning = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeContainedInValueMeaningSet(MdrValueMeaning aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeContainedInValueMeaningSet(aDomain,aRange,null); 
	} 

	/**
	* writes a ContainedInValueMeaningSet relation between a MdrValueMeaning and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrValueMeaning = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeContainedInValueMeaningSet(MdrValueMeaning aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderContainedInValueMeaningSet(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ContainedInValueMeaningSet relation between a MdrValueMeaning and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrValueMeaning = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderContainedInValueMeaningSet(MdrValueMeaning aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.containedInValueMeaningSet, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMemberValueMeaningSet, aDomain.getUri());
		return builder; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasDefinitionItemDefinition(MdrDefinition filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasDefinitionItemDefinitionSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasDefinitionItemDefinitionMdrDefinition(Set<MdrDefinition> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByHasDefinitionItemDefinition(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseHasMeaningValueDomainMeaning(MdrValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#hasMeaningValueDomainMeaning>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseHasMeaningValueDomainMeaningMdrValueDomain(Set<MdrValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByInverseHasMeaningValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaning(MdrDescribedValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasRepresentionValueDomainMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaningMdrDescribedValueDomain(Set<MdrDescribedValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaning(MdrEnumeratedValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasRepresentionValueDomainMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaningMdrEnumeratedValueDomain(Set<MdrEnumeratedValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaning(MdrValueDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasRepresentionValueDomainMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaningMdrValueDomain(Set<MdrValueDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByHasRepresentionValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseUsesDataElementConceptDomain(MdrDataElementConcept filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usesDataElementConceptDomain>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseUsesDataElementConceptDomainMdrDataElementConcept(Set<MdrDataElementConcept> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByInverseUsesDataElementConceptDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasMemberValueMeaningSet(MdrValueMeaning filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasMemberValueMeaningSetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasMemberValueMeaningSetMdrValueMeaning(Set<MdrValueMeaning> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByHasMemberValueMeaningSet(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseUsedForItemItemDefinition(MdrDefinition filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usedForItemItemDefinition>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseUsedForItemItemDefinitionMdrDefinition(Set<MdrDefinition> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByInverseUsedForItemItemDefinition(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseUsedForItemItemDesignation(MdrDesignation filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usedForItemItemDesignation>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseUsedForItemItemDesignationMdrDesignation(Set<MdrDesignation> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByInverseUsedForItemItemDesignation(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasDesignationItemDesignation(MdrDesignation filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasDesignationItemDesignationSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByHasDesignationItemDesignationMdrDesignation(Set<MdrDesignation> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByHasDesignationItemDesignation(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseAttachedToAttachment(MdrAttachedItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#attachedToAttachment>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseAttachedToAttachmentMdrAttachedItem(Set<MdrAttachedItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByInverseAttachedToAttachment(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByProvidesDomainForDataElementConceptDomain(MdrDataElementConcept filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.providesDomainForDataElementConceptDomainSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByProvidesDomainForDataElementConceptDomainMdrDataElementConcept(Set<MdrDataElementConcept> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByProvidesDomainForDataElementConceptDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseContainedInValueMeaningSet(MdrValueMeaning filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedConceptualDomain> domains = new HashMap<IRI,MdrEnumeratedConceptualDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#containedInValueMeaningSet>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedConceptualDomain domain = new MdrEnumeratedConceptualDomain();
					domain = (MdrEnumeratedConceptualDomain) new Binder(new MdrEnumeratedConceptualDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedConceptualDomain domain2=domains.get(domain.getUri());
							domain.addAllDimensionality(domain2.getDimensionality());
							domain.addAllComment(domain2.getComment());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedConceptualDomain> findMdrEnumeratedConceptualDomainByInverseContainedInValueMeaningSetMdrValueMeaning(Set<MdrValueMeaning> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedConceptualDomain> result = new HashSet<MdrEnumeratedConceptualDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedConceptualDomainByInverseContainedInValueMeaningSet(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

}
