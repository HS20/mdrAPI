package mdrApi.generatedDAO;


import org.apache.log4j.Logger;
import java.util.Set;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import org.eclipse.rdf4j.query.BindingSet;
import java.util.List;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import mdrApi.generatedVocabulary.MDRVOCABULARY;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.IRI;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.lang.reflect.InvocationTargetException;
import generateJavaClass.service.Binder;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrEnumeratedValueDomain;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.util.HashSet;
import mdrApi.generatedDomain.MdrProperty;
import mdrApi.generatedDomain.MdrDescribedValueDomain;
import mdrApi.generatedDomain.MdrObjectClass;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrDescribedConceptualDomain;
import mdrApi.generatedDomain.MdrIdentifiedItem;
import mdrApi.generatedDomain.MdrRegisteredItem;
import mdrApi.generatedDomain.MdrDesignatableItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrEnumeratedConceptualDomain;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;

public class MdrEnumeratedValueDomainDAO extends MdrValueDomainDAO {
	protected static final Logger log = Logger.getLogger(MdrEnumeratedValueDomainDAO.class);
	private String selectRead = " ?type ?uri  ?comment  ?unitOfMeasure  ?dataType  ?label  ?format  ?maximumCharacterQuantity  ";
	private String whereRead = "   ?uri a ?type . \n ?uri a "+MDRVOCABULARY.EnumeratedValueDomainSparql+" . \n OPTIONAL {?uri "+MDRVOCABULARY.commentSparql+" ?comment . } \n  OPTIONAL {?uri "+MDRVOCABULARY.unitOfMeasureSparql+" ?unitOfMeasure . } \n  OPTIONAL {?uri "+MDRVOCABULARY.dataTypeSparql+" ?dataType . } \n  OPTIONAL {?uri "+MDRVOCABULARY.labelSparql+" ?label . } \n  OPTIONAL {?uri "+MDRVOCABULARY.formatSparql+" ?format . } \n  OPTIONAL {?uri "+MDRVOCABULARY.maximumCharacterQuantitySparql+" ?maximumCharacterQuantity . } \n  ";

	public MdrEnumeratedValueDomainDAO(BlazeGraphClient client) {
		super(client);

	}




	public MdrEnumeratedValueDomain readMdrEnumeratedValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" \n where { BIND (<" + uri + "> as ?uri) \n ?uri a "+MDRVOCABULARY.EnumeratedValueDomainSparql+" . \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().findFirst().get();
 
	} 

	public Set<MdrEnumeratedValueDomain> readAllMdrEnumeratedValueDomain() throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  ?uri a "+MDRVOCABULARY.EnumeratedValueDomainSparql+" . \n " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> readAllMdrEnumeratedValueDomain(StringBuilder filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
		String req="";
		req+= client.getPrefixSarql() ;
		req+=" select  "+selectRead+"  ";
		req+=" where { \n  ?uri a "+MDRVOCABULARY.EnumeratedValueDomainSparql+" . \n " + filter.toString() + " " + whereRead + "} ";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	/**
	* writes a MdrEnumeratedValueDomain definition to a repository statements will be written in the default graph
	* @param domain a MdrEnumeratedValueDomain = the class to be added
	*/


	public void write(MdrEnumeratedValueDomain domain) {
		write(domain,null); 
	} 

	/**
	* writes a MdrEnumeratedValueDomain definition to a repository in a specified graph 
	* @param domain a MdrEnumeratedValueDomain = the class to be added
	* @param graph the graph into which statements will be written
	*/


	public void write(MdrEnumeratedValueDomain domain,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilder(builder,domain);
		addToRepo(builder,graph); 
	} 

	/**
	* adds a MdrEnumeratedValueDomain definition to a rdf4j ModelBuilder 
	* @param builder the rdf4j ModelBuilder to feed
	* @param domain a MdrEnumeratedValueDomain = the class to be added
	*/


	public ModelBuilder addToBuilder(ModelBuilder builder,MdrEnumeratedValueDomain domain) {
		builder.subject(domain.getUri().toString());
		if (domain.hasComment()){
				domain.getComment().forEach( x -> {
					builder.add(MDRVOCABULARY.comment, x);
			});
		}
		if (domain.hasUnitOfMeasure()){
				domain.getUnitOfMeasure().forEach( x -> {
					builder.add(MDRVOCABULARY.unitOfMeasure, x);
			});
		}
		if (domain.hasDataType()){
				domain.getDataType().forEach( x -> {
					builder.add(MDRVOCABULARY.dataType, x);
			});
		}
		if (domain.hasLabel()){
				domain.getLabel().forEach( x -> {
					builder.add(MDRVOCABULARY.label, x);
			});
		}
		if (domain.hasFormat()){
				domain.getFormat().forEach( x -> {
					builder.add(MDRVOCABULARY.format, x);
			});
		}
		if (domain.hasMaximumCharacterQuantity()){
				domain.getMaximumCharacterQuantity().forEach( x -> {
					builder.add(MDRVOCABULARY.maximumCharacterQuantity, x);
			});
		}
		builder.add(RDF.TYPE, MDRVOCABULARY.EnumeratedValueDomain);
		return builder; 
	} 

	/**
	* writes a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange) {
 		writeHasDefinitionItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinitionin the repository 
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasDefinitionItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasDefinitionItemDefinition relation between a MdrMetadatatItem and a MdrDefinition
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasDefinitionItemDefinition(MdrMetadatatItem aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ContainsDomainPermissibleValueSet relation between a MdrPermissibleValue and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrPermissibleValue = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeContainsDomainPermissibleValueSet(MdrPermissibleValue aDomain,MdrEnumeratedValueDomain aRange) {
 		writeContainsDomainPermissibleValueSet(aDomain,aRange,null); 
	} 

	/**
	* writes a ContainsDomainPermissibleValueSet relation between a MdrPermissibleValue and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrPermissibleValue = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeContainsDomainPermissibleValueSet(MdrPermissibleValue aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderContainsDomainPermissibleValueSet(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ContainsDomainPermissibleValueSet relation between a MdrPermissibleValue and a MdrEnumeratedValueDomain
	* @param aDomain a MdrPermissibleValue = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderContainsDomainPermissibleValueSet(MdrPermissibleValue aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.containsDomainPermissibleValueSet, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMemberPermissibleValueSet, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMemberPermissibleValueSet relation between a MdrEnumeratedValueDomain and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrEnumeratedValueDomain = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeHasMemberPermissibleValueSet(MdrEnumeratedValueDomain aDomain,MdrPermissibleValue aRange) {
 		writeHasMemberPermissibleValueSet(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMemberPermissibleValueSet relation between a MdrEnumeratedValueDomain and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrEnumeratedValueDomain = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMemberPermissibleValueSet(MdrEnumeratedValueDomain aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMemberPermissibleValueSet(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMemberPermissibleValueSet relation between a MdrEnumeratedValueDomain and a MdrPermissibleValue
	* @param aDomain a MdrEnumeratedValueDomain = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMemberPermissibleValueSet(MdrEnumeratedValueDomain aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMemberPermissibleValueSet, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.containsDomainPermissibleValueSet, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContextin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContextin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrContext
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrContext aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignationin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignation
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClassin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrObjectClass
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMetadatatItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrMetadatatItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinitionin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDefinition
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrRegisteredItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrRegisteredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrIdentifiedItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrIdentifiedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDesignatableItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDesignatableItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElement
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAdministeredItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrCompositeInformationItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPermissibleValue
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrMappableRelationshipItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrDataElementConcept
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrConceptualDomain
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItemin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrAttachedItem
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrAttachedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrPropertyin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrProperty
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange) {
 		writeUsedForItemItemDefinition(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaningin the repository 
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDefinition(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDefinition relation between a MdrDefinition and a MdrValueMeaning
	* @param aDomain a MdrDefinition = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDefinition(MdrDefinition aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDefinition, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDefinitionItemDefinition, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrDescribedConceptualDomain aRange) {
 		writeHasMeaningValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMeaningValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrDescribedConceptualDomain
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeHasMeaningValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMeaningValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrConceptualDomain aRange) {
 		writeHasMeaningValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasMeaningValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasMeaningValueDomainMeaning relation between a MdrValueDomain and a MdrConceptualDomain
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasMeaningValueDomainMeaning(MdrValueDomain aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContextin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContextin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrContext
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrContext = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrContext aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignationin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignation
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDescribedConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClassin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrObjectClass
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMetadatatItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMetadatatItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrMetadatatItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinitionin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinitionin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDefinition
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDefinition = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDefinition aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrRegisteredItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrRegisteredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrRegisteredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrIdentifiedItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrIdentifiedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrIdentifiedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDesignatableItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDesignatableItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDesignatableItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElement
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAdministeredItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrCompositeInformationItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrCompositeInformationItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrCompositeInformationItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValuein the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValuein the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPermissibleValue
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrPermissibleValue = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrPermissibleValue aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrMappableRelationshipItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrMappableRelationshipItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrMappableRelationshipItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrDataElementConcept
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrConceptualDomain
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItemin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItemin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrAttachedItem
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrAttachedItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrAttachedItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrPropertyin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrProperty
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaningin the repository statements will be written in the default graph
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange) {
 		writeUsedForItemItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaningin the repository 
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsedForItemItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsedForItemItemDesignation relation between a MdrDesignation and a MdrValueMeaning
	* @param aDomain a MdrDesignation = domain described by the relation
	* @param aRange a MdrValueMeaning = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsedForItemItemDesignation(MdrDesignation aDomain,MdrValueMeaning aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignationin the repository statements will be written in the default graph
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	*/


	public void writeHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange) {
 		writeHasDesignationItemDesignation(aDomain,aRange,null); 
	} 

	/**
	* writes a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignationin the repository 
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasDesignationItemDesignation(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasDesignationItemDesignation relation between a MdrMetadatatItem and a MdrDesignation
	* @param aDomain a MdrMetadatatItem = domain described by the relation
	* @param aRange a MdrDesignation = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasDesignationItemDesignation(MdrMetadatatItem aDomain,MdrDesignation aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasDesignationItemDesignation, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usedForItemItemDesignation, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElement
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDescribedConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDescribedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDescribedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItemin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItemin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrAdministeredItem
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrAdministeredItem = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrAdministeredItem aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClassin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClassin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrObjectClass
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrObjectClass = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrObjectClass aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrEnumeratedValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConceptin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConceptin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrDataElementConcept
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrDataElementConcept = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrDataElementConcept aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrConceptualDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrConceptualDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrConceptualDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomainin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrValueDomain
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrPropertyin the repository statements will be written in the default graph
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange) {
 		writeAttachedToAttachment(aDomain,aRange,null); 
	} 

	/**
	* writes a AttachedToAttachment relation between a MdrAttachedItem and a MdrPropertyin the repository 
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderAttachedToAttachment(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a AttachedToAttachment relation between a MdrAttachedItem and a MdrProperty
	* @param aDomain a MdrAttachedItem = domain described by the relation
	* @param aRange a MdrProperty = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderAttachedToAttachment(MdrAttachedItem aDomain,MdrProperty aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.attachedToAttachment, aRange.getUri());
		return builder; 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrDescribedValueDomain aRange) {
 		writeHasRepresentionValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasRepresentionValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrDescribedValueDomain
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrEnumeratedValueDomain aRange) {
 		writeHasRepresentionValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasRepresentionValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrEnumeratedValueDomain
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrValueDomain aRange) {
 		writeHasRepresentionValueDomainMeaning(aDomain,aRange,null); 
	} 

	/**
	* writes a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrValueDomainin the repository 
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderHasRepresentionValueDomainMeaning(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a HasRepresentionValueDomainMeaning relation between a MdrConceptualDomain and a MdrValueDomain
	* @param aDomain a MdrConceptualDomain = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderHasRepresentionValueDomainMeaning(MdrConceptualDomain aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.hasRepresentionValueDomainMeaning, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.hasMeaningValueDomainMeaning, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a ProvidesValuesForDataElementDomain relation between a MdrValueDomain and a MdrDataElementin the repository statements will be written in the default graph
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	*/


	public void writeProvidesValuesForDataElementDomain(MdrValueDomain aDomain,MdrDataElement aRange) {
 		writeProvidesValuesForDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a ProvidesValuesForDataElementDomain relation between a MdrValueDomain and a MdrDataElementin the repository 
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeProvidesValuesForDataElementDomain(MdrValueDomain aDomain,MdrDataElement aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderProvidesValuesForDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a ProvidesValuesForDataElementDomain relation between a MdrValueDomain and a MdrDataElement
	* @param aDomain a MdrValueDomain = domain described by the relation
	* @param aRange a MdrDataElement = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderProvidesValuesForDataElementDomain(MdrValueDomain aDomain,MdrDataElement aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrDescribedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrDescribedValueDomain aRange) {
 		writeUsesDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrDescribedValueDomainin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrDescribedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementDomain relation between a MdrDataElement and a MdrDescribedValueDomain
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrDescribedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementDomain(MdrDataElement aDomain,MdrDescribedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrEnumeratedValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrEnumeratedValueDomain aRange) {
 		writeUsesDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrEnumeratedValueDomainin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrEnumeratedValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementDomain relation between a MdrDataElement and a MdrEnumeratedValueDomain
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrEnumeratedValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementDomain(MdrDataElement aDomain,MdrEnumeratedValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrValueDomainin the repository statements will be written in the default graph
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrValueDomain aRange) {
 		writeUsesDataElementDomain(aDomain,aRange,null); 
	} 

	/**
	* writes a UsesDataElementDomain relation between a MdrDataElement and a MdrValueDomainin the repository 
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param graph the graph into which statements will be written
	*/


	public void writeUsesDataElementDomain(MdrDataElement aDomain,MdrValueDomain aRange,String graph) {
		ModelBuilder builder=new ModelBuilder();
		builder=addToBuilderUsesDataElementDomain(aDomain,aRange,builder);
		addToRepo(builder,graph); 
	} 

	/**
	* Adds a UsesDataElementDomain relation between a MdrDataElement and a MdrValueDomain
	* @param aDomain a MdrDataElement = domain described by the relation
	* @param aRange a MdrValueDomain = range pointed by the relation
	* @param builder the rdf4j ModelBuilder to feed
	*/


	public ModelBuilder addToBuilderUsesDataElementDomain(MdrDataElement aDomain,MdrValueDomain aRange,ModelBuilder builder) {
		builder
			.subject(aDomain.getUri().toString())
			.add(MDRVOCABULARY.usesDataElementDomain, aRange.getUri());
		builder
			.subject(aRange.getUri().toString())
			.add(MDRVOCABULARY.providesValuesForDataElementDomain, aDomain.getUri());
		return builder; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasDefinitionItemDefinition(MdrDefinition filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasDefinitionItemDefinitionSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasDefinitionItemDefinitionMdrDefinition(Set<MdrDefinition> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByHasDefinitionItemDefinition(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseContainsDomainPermissibleValueSet(MdrPermissibleValue filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#containsDomainPermissibleValueSet>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseContainsDomainPermissibleValueSetMdrPermissibleValue(Set<MdrPermissibleValue> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByInverseContainsDomainPermissibleValueSet(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMemberPermissibleValueSet(MdrPermissibleValue filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasMemberPermissibleValueSetSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMemberPermissibleValueSetMdrPermissibleValue(Set<MdrPermissibleValue> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByHasMemberPermissibleValueSet(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseUsedForItemItemDefinition(MdrDefinition filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usedForItemItemDefinition>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseUsedForItemItemDefinitionMdrDefinition(Set<MdrDefinition> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByInverseUsedForItemItemDefinition(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaning(MdrConceptualDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasMeaningValueDomainMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaningMdrConceptualDomain(Set<MdrConceptualDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaning(MdrEnumeratedConceptualDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasMeaningValueDomainMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaningMdrEnumeratedConceptualDomain(Set<MdrEnumeratedConceptualDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaning(MdrDescribedConceptualDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasMeaningValueDomainMeaningSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaningMdrDescribedConceptualDomain(Set<MdrDescribedConceptualDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByHasMeaningValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseUsedForItemItemDesignation(MdrDesignation filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usedForItemItemDesignation>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseUsedForItemItemDesignationMdrDesignation(Set<MdrDesignation> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByInverseUsedForItemItemDesignation(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasDesignationItemDesignation(MdrDesignation filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.hasDesignationItemDesignationSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByHasDesignationItemDesignationMdrDesignation(Set<MdrDesignation> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByHasDesignationItemDesignation(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseAttachedToAttachment(MdrAttachedItem filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#attachedToAttachment>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseAttachedToAttachmentMdrAttachedItem(Set<MdrAttachedItem> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByInverseAttachedToAttachment(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseHasRepresentionValueDomainMeaning(MdrConceptualDomain filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#hasRepresentionValueDomainMeaning>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseHasRepresentionValueDomainMeaningMdrConceptualDomain(Set<MdrConceptualDomain> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByInverseHasRepresentionValueDomainMeaning(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByProvidesValuesForDataElementDomain(MdrDataElement filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {   ?uri "+MDRVOCABULARY.providesValuesForDataElementDomainSparql+" <" + uriFilter + "> . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByProvidesValuesForDataElementDomainMdrDataElement(Set<MdrDataElement> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByProvidesValuesForDataElementDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseUsesDataElementDomain(MdrDataElement filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			HashMap<IRI,MdrEnumeratedValueDomain> domains = new HashMap<IRI,MdrEnumeratedValueDomain>();
			String uriFilter =filter.getUri().toString();
			String req="";
			req+=" 		select "+selectRead+"  \n";
			req+=" 		where {     <" + uriFilter + "> <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usesDataElementDomain>  ?uri . \n  " + whereRead +" }";
		List<BindingSet> list = client.getRdf4jClient().execTupleQuery(req);
		if (list.isEmpty()){
			log.error("No entity retrieved");
		}else{
			for (BindingSet l : list) {
					MdrEnumeratedValueDomain domain = new MdrEnumeratedValueDomain();
					domain = (MdrEnumeratedValueDomain) new Binder(new MdrEnumeratedValueDomain()).bindAllAttributes(l);
						if (domains.containsKey(domain.getUri())){
							MdrEnumeratedValueDomain domain2=domains.get(domain.getUri());
							domain.addAllComment(domain2.getComment());
							domain.addAllUnitOfMeasure(domain2.getUnitOfMeasure());
							domain.addAllDataType(domain2.getDataType());
							domain.addAllLabel(domain2.getLabel());
							domain.addAllFormat(domain2.getFormat());
							domain.addAllMaximumCharacterQuantity(domain2.getMaximumCharacterQuantity());
							domain.addAllType(domain2.getType());
						}
						domains.get(domain.getUri());
						domains.put(domain.getUri(),domain);
					}
			}
			return domains.values().stream().collect(Collectors.toSet());
 
	} 

	public Set<MdrEnumeratedValueDomain> findMdrEnumeratedValueDomainByInverseUsesDataElementDomainMdrDataElement(Set<MdrDataElement> filter) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {			Set<MdrEnumeratedValueDomain> result = new HashSet<MdrEnumeratedValueDomain>();
			filter.forEach( f -> {
				try{
					result.addAll(findMdrEnumeratedValueDomainByInverseUsesDataElementDomain(f));
				} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});			return result; 
	} 

}
