package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrDescribedValueDomainDAO;
import mdrApi.generatedDAO.MdrDescribedConceptualDomainDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrDataElementConceptDAO;
import mdrApi.generatedDAO.MdrConceptualDomainDAO;
import mdrApi.generatedDAO.MdrValueDomainDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrDescribedValueDomain;
import mdrApi.generatedDomain.MdrDescribedConceptualDomain;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrDescribedConceptualDomainServiceImpl extends MdrConceptualDomainServiceImpl implements MdrDescribedConceptualDomainService {
	protected static final Logger log = Logger.getLogger(MdrDescribedConceptualDomainServiceImpl.class);

	public MdrDescribedConceptualDomainServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrDescribedConceptualDomain readMdrDescribedConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDescribedConceptualDomainDAO(client).readMdrDescribedConceptualDomain(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrDescribedConceptualDomain(uri)); 
	} 

	public Set<MdrValueDomain> hasRepresentionValueDomainMeaningMdrValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrValueDomainDAO(client).findMdrValueDomainByHasMeaningValueDomainMeaning(new MdrDescribedConceptualDomain(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrDescribedConceptualDomain(uri)); 
	} 

	public Set<MdrDataElementConcept> providesDomainForDataElementConceptDomainMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementConceptDAO(client).findMdrDataElementConceptByUsesDataElementConceptDomain(new MdrDescribedConceptualDomain(uri)); 
	} 

	public Set<MdrDescribedValueDomain> hasRepresentationDescribedValueDomainMeaningMdrDescribedValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDescribedValueDomainDAO(client).findMdrDescribedValueDomainByHasMeaningDescribedValueDomainMeaning(new MdrDescribedConceptualDomain(uri)); 
	} 

}
