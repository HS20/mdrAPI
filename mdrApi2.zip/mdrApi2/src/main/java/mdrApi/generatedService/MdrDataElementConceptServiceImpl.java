package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrDataElementDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrObjectClassDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrDataElementConceptDAO;
import mdrApi.generatedDAO.MdrConceptualDomainDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDAO.MdrPropertyDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrObjectClass;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import mdrApi.generatedDomain.MdrProperty;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrDataElementConceptServiceImpl extends MdrAdministeredItemServiceImpl implements MdrDataElementConceptService {
	protected static final Logger log = Logger.getLogger(MdrDataElementConceptServiceImpl.class);

	public MdrDataElementConceptServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrDataElementConcept readMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementConceptDAO(client).readMdrDataElementConcept(uri); 
	} 

	public Set<MdrDataElement> providesMeaningForDataElementMeaningMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementDAO(client).findMdrDataElementByRepresentsDataElementMeaning(new MdrDataElementConcept(uri)); 
	} 

	public Set<MdrObjectClass> hasObjectClassDataElementConceptObjectClassMdrObjectClass(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrObjectClassDAO(client).findMdrObjectClassByHasDataElementConceptDataElementConceptObjectClass(new MdrDataElementConcept(uri)); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrDataElementConcept(uri)); 
	} 

	public Set<MdrProperty> hasPropertydataElementConceptPropertyMdrProperty(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrPropertyDAO(client).findMdrPropertyByHasDataElementConceptDataElementConceptProperty(new MdrDataElementConcept(uri)); 
	} 

	public Set<MdrConceptualDomain> usesDataElementConceptDomainMdrConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrConceptualDomainDAO(client).findMdrConceptualDomainByProvidesDomainForDataElementConceptDomain(new MdrDataElementConcept(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrDataElementConcept(uri)); 
	} 

}
