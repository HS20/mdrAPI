package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrCompositeInformationItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrMappableRelationshipItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrCompositeInformationItemServiceImpl extends MdrMappableRelationshipItemServiceImpl implements MdrCompositeInformationItemService {
	protected static final Logger log = Logger.getLogger(MdrCompositeInformationItemServiceImpl.class);

	public MdrCompositeInformationItemServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrCompositeInformationItem readMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrCompositeInformationItemDAO(client).readMdrCompositeInformationItem(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> composedOfMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByIsComponentOf(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrCompositeInformationItem> isComponentOfMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrCompositeInformationItemDAO(client).findMdrCompositeInformationItemByIsComponentOf(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasSource(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleSource(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasTarget(new MdrCompositeInformationItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleTarget(new MdrCompositeInformationItem(uri)); 
	} 

}
