package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrEnumeratedConceptualDomain;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrEnumeratedConceptualDomainService extends MdrConceptualDomainService {






 MdrEnumeratedConceptualDomain readMdrEnumeratedConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrValueDomain> hasRepresentionValueDomainMeaningMdrValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrValueMeaning> hasMemberValueMeaningSetMdrValueMeaning(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDataElementConcept> providesDomainForDataElementConceptDomainMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
