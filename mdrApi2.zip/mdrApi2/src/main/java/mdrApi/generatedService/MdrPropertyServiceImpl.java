package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrDataElementConceptDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDAO.MdrPropertyDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrAttachedItem;
import mdrApi.generatedDomain.MdrProperty;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrPropertyServiceImpl extends MdrAdministeredItemServiceImpl implements MdrPropertyService {
	protected static final Logger log = Logger.getLogger(MdrPropertyServiceImpl.class);

	public MdrPropertyServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrProperty readMdrProperty(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrPropertyDAO(client).readMdrProperty(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrProperty(uri)); 
	} 

	public Set<MdrDataElementConcept> hasDataElementConceptDataElementConceptPropertyMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementConceptDAO(client).findMdrDataElementConceptByHasPropertydataElementConceptProperty(new MdrProperty(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrProperty(uri)); 
	} 

}
