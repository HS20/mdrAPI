package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrCompositeInformationItemDAO;
import mdrApi.generatedDAO.MdrEnumeratedValueDomainDAO;
import mdrApi.generatedDAO.MdrPermissibleValueDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrMappableRelationshipItemDAO;
import mdrApi.generatedDAO.MdrValueMeaningDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrEnumeratedValueDomain;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrPermissibleValueServiceImpl extends MdrMappableRelationshipItemServiceImpl implements MdrPermissibleValueService {
	protected static final Logger log = Logger.getLogger(MdrPermissibleValueServiceImpl.class);

	public MdrPermissibleValueServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrPermissibleValue readMdrPermissibleValue(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrPermissibleValueDAO(client).readMdrPermissibleValue(uri); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleTarget(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrCompositeInformationItem> isComponentOfMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrCompositeInformationItemDAO(client).findMdrCompositeInformationItemByComposedOf(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasSource(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleSource(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrEnumeratedValueDomain> containsDomainPermissibleValueSetMdrEnumeratedValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrEnumeratedValueDomainDAO(client).findMdrEnumeratedValueDomainByHasMemberPermissibleValueSet(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrValueMeaning> hasMeaningPermissibleValueMeaningMdrValueMeaning(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrValueMeaningDAO(client).findMdrValueMeaningByHasRepresentationPermissibleValueMeaning(new MdrPermissibleValue(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasTarget(new MdrPermissibleValue(uri)); 
	} 

}
