package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrDescribedValueDomain;
import mdrApi.generatedDomain.MdrDescribedConceptualDomain;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrDescribedValueDomainService extends MdrValueDomainService {






 MdrDescribedValueDomain readMdrDescribedValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDescribedConceptualDomain> hasMeaningDescribedValueDomainMeaningMdrDescribedConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrConceptualDomain> hasMeaningValueDomainMeaningMdrConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDataElement> providesValuesForDataElementDomainMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
