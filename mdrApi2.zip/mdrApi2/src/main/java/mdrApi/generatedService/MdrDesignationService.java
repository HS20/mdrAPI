package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrDesignationService extends MdrMetadatatItemService {






 MdrDesignation readMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMetadatatItem> usedForItemItemDesignationMdrMetadatatItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrContext> occursInScopeDesignationContextMdrContext(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
