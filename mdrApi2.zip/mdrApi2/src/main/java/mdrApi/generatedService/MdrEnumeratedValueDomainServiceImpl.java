package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDataElementDAO;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrPermissibleValueDAO;
import mdrApi.generatedDAO.MdrEnumeratedValueDomainDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrConceptualDomainDAO;
import mdrApi.generatedDAO.MdrValueDomainDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrEnumeratedValueDomain;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrEnumeratedValueDomainServiceImpl extends MdrValueDomainServiceImpl implements MdrEnumeratedValueDomainService {
	protected static final Logger log = Logger.getLogger(MdrEnumeratedValueDomainServiceImpl.class);

	public MdrEnumeratedValueDomainServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrEnumeratedValueDomain readMdrEnumeratedValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrEnumeratedValueDomainDAO(client).readMdrEnumeratedValueDomain(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrEnumeratedValueDomain(uri)); 
	} 

	public Set<MdrPermissibleValue> hasMemberPermissibleValueSetMdrPermissibleValue(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrPermissibleValueDAO(client).findMdrPermissibleValueByContainsDomainPermissibleValueSet(new MdrEnumeratedValueDomain(uri)); 
	} 

	public Set<MdrConceptualDomain> hasMeaningValueDomainMeaningMdrConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrConceptualDomainDAO(client).findMdrConceptualDomainByHasRepresentionValueDomainMeaning(new MdrEnumeratedValueDomain(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrEnumeratedValueDomain(uri)); 
	} 

	public Set<MdrDataElement> providesValuesForDataElementDomainMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementDAO(client).findMdrDataElementByUsesDataElementDomain(new MdrEnumeratedValueDomain(uri)); 
	} 

}
