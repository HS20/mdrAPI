package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrEnumeratedConceptualDomainDAO;
import mdrApi.generatedDAO.MdrPermissibleValueDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDAO.MdrValueMeaningDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrEnumeratedConceptualDomain;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrAttachedItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrValueMeaningServiceImpl extends MdrAttachedItemServiceImpl implements MdrValueMeaningService {
	protected static final Logger log = Logger.getLogger(MdrValueMeaningServiceImpl.class);

	public MdrValueMeaningServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrValueMeaning readMdrValueMeaning(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrValueMeaningDAO(client).readMdrValueMeaning(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrValueMeaning(uri)); 
	} 

	public Set<MdrAdministeredItem> attachedToAttachmentMdrAdministeredItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrAdministeredItemDAO(client).findMdrAdministeredItemByInverseAttachedToAttachment(new MdrValueMeaning(uri)); 
	} 

	public Set<MdrEnumeratedConceptualDomain> containedInValueMeaningSetMdrEnumeratedConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrEnumeratedConceptualDomainDAO(client).findMdrEnumeratedConceptualDomainByHasMemberValueMeaningSet(new MdrValueMeaning(uri)); 
	} 

	public Set<MdrPermissibleValue> hasRepresentationPermissibleValueMeaningMdrPermissibleValue(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrPermissibleValueDAO(client).findMdrPermissibleValueByHasMeaningPermissibleValueMeaning(new MdrValueMeaning(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrValueMeaning(uri)); 
	} 

}
