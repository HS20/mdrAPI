package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrDataElementDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrConceptualDomainDAO;
import mdrApi.generatedDAO.MdrValueDomainDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrConceptualDomain;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrValueDomainServiceImpl extends MdrAdministeredItemServiceImpl implements MdrValueDomainService {
	protected static final Logger log = Logger.getLogger(MdrValueDomainServiceImpl.class);

	public MdrValueDomainServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrValueDomain readMdrValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrValueDomainDAO(client).readMdrValueDomain(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrValueDomain(uri)); 
	} 

	public Set<MdrConceptualDomain> hasMeaningValueDomainMeaningMdrConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrConceptualDomainDAO(client).findMdrConceptualDomainByHasRepresentionValueDomainMeaning(new MdrValueDomain(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrValueDomain(uri)); 
	} 

	public Set<MdrDataElement> providesValuesForDataElementDomainMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementDAO(client).findMdrDataElementByUsesDataElementDomain(new MdrValueDomain(uri)); 
	} 

}
