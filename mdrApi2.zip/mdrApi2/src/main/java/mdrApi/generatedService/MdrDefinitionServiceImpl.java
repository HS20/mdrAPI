package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrContextDAO;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrDefinitionServiceImpl extends MdrMetadatatItemServiceImpl implements MdrDefinitionService {
	protected static final Logger log = Logger.getLogger(MdrDefinitionServiceImpl.class);

	public MdrDefinitionServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrDefinition readMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).readMdrDefinition(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByHasDefinitionItemDefinition(new MdrDefinition(uri)); 
	} 

	public Set<MdrContext> occursInScopeDefinitionContextMdrContext(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrContextDAO(client).findMdrContextByIncludesRelevantDefinitionDefinitionContext(new MdrDefinition(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrDefinition(uri)); 
	} 

	public Set<MdrMetadatatItem> usedForItemItemDefinitionMdrMetadatatItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMetadatatItemDAO(client).findMdrMetadatatItemByHasDefinitionItemDefinition(new MdrDefinition(uri)); 
	} 

}
