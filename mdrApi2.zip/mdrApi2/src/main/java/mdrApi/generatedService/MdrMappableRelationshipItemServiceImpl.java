package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrCompositeInformationItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrMappableRelationshipItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrMappableRelationshipItemServiceImpl extends MdrMetadatatItemServiceImpl implements MdrMappableRelationshipItemService {
	protected static final Logger log = Logger.getLogger(MdrMappableRelationshipItemServiceImpl.class);

	public MdrMappableRelationshipItemServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrMappableRelationshipItem readMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).readMdrMappableRelationshipItem(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrMappableRelationshipItem(uri)); 
	} 

	public Set<MdrCompositeInformationItem> isComponentOfMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrCompositeInformationItemDAO(client).findMdrCompositeInformationItemByComposedOf(new MdrMappableRelationshipItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasSource(new MdrMappableRelationshipItem(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrMappableRelationshipItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleSource(new MdrMappableRelationshipItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasTarget(new MdrMappableRelationshipItem(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleTarget(new MdrMappableRelationshipItem(uri)); 
	} 

}
