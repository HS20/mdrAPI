package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrMetadatatItemService extends MdrThingService {






 MdrMetadatatItem readMdrMetadatatItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
