package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrContextDAO;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrContextServiceImpl extends MdrMetadatatItemServiceImpl implements MdrContextService {
	protected static final Logger log = Logger.getLogger(MdrContextServiceImpl.class);

	public MdrContextServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrContext readMdrContext(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrContextDAO(client).readMdrContext(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrContext(uri)); 
	} 

	public Set<MdrDefinition> includesRelevantDefinitionDefinitionContextMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByOccursInScopeDefinitionContext(new MdrContext(uri)); 
	} 

	public Set<MdrContext> isUsedAsSourceOfMdrContext(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrContextDAO(client).findMdrContextByIsUsedAsSourceOf(new MdrContext(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrContext(uri)); 
	} 

	public Set<MdrDesignation> includesRelevantDesignationDesignationContextMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByOccursInScopeDesignationContext(new MdrContext(uri)); 
	} 

	public Set<MdrContext> isUsedAsTargetOfMdrContext(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrContextDAO(client).findMdrContextByIsUsedAsTargetOf(new MdrContext(uri)); 
	} 

}
