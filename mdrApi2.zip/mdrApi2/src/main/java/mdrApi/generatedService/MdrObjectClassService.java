package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrObjectClass;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrObjectClassService extends MdrAdministeredItemService {






 MdrObjectClass readMdrObjectClass(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDataElementConcept> hasDataElementConceptDataElementConceptObjectClassMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
