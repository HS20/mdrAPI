package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrObjectClassDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrDataElementConceptDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrObjectClass;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrObjectClassServiceImpl extends MdrAdministeredItemServiceImpl implements MdrObjectClassService {
	protected static final Logger log = Logger.getLogger(MdrObjectClassServiceImpl.class);

	public MdrObjectClassServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrObjectClass readMdrObjectClass(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrObjectClassDAO(client).readMdrObjectClass(uri); 
	} 

	public Set<MdrDataElementConcept> hasDataElementConceptDataElementConceptObjectClassMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementConceptDAO(client).findMdrDataElementConceptByHasObjectClassDataElementConceptObjectClass(new MdrObjectClass(uri)); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrObjectClass(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrObjectClass(uri)); 
	} 

}
