package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrMappableRelationshipItemService extends MdrMetadatatItemService {






 MdrMappableRelationshipItem readMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrCompositeInformationItem> isComponentOfMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasPossibleSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasPossibleTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
