package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrMetadatatItemServiceImpl extends MdrThingServiceImpl implements MdrMetadatatItemService {
	protected static final Logger log = Logger.getLogger(MdrMetadatatItemServiceImpl.class);

	public MdrMetadatatItemServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrMetadatatItem readMdrMetadatatItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMetadatatItemDAO(client).readMdrMetadatatItem(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrMetadatatItem(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrMetadatatItem(uri)); 
	} 

}
