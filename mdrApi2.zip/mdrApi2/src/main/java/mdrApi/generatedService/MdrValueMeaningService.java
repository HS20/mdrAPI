package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrEnumeratedConceptualDomain;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrAttachedItem;
import mdrApi.generatedDomain.MdrValueMeaning;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrValueMeaningService extends MdrAttachedItemService {






 MdrValueMeaning readMdrValueMeaning(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrAdministeredItem> attachedToAttachmentMdrAdministeredItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrEnumeratedConceptualDomain> containedInValueMeaningSetMdrEnumeratedConceptualDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrPermissibleValue> hasRepresentationPermissibleValueMeaningMdrPermissibleValue(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
