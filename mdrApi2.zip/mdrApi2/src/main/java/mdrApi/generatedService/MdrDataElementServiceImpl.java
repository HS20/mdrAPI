package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrDataElementDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrCompositeInformationItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrMappableRelationshipItemDAO;
import mdrApi.generatedDAO.MdrDataElementConceptDAO;
import mdrApi.generatedDAO.MdrValueDomainDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrDataElementServiceImpl extends MdrThingServiceImpl implements MdrDataElementService {
	protected static final Logger log = Logger.getLogger(MdrDataElementServiceImpl.class);

	public MdrDataElementServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrDataElement readMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementDAO(client).readMdrDataElement(uri); 
	} 

	public Set<MdrDataElementConcept> representsDataElementMeaningMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDataElementConceptDAO(client).findMdrDataElementConceptByProvidesMeaningForDataElementMeaning(new MdrDataElement(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleTarget(new MdrDataElement(uri)); 
	} 

	public Set<MdrValueDomain> usesDataElementDomainMdrValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrValueDomainDAO(client).findMdrValueDomainByProvidesValuesForDataElementDomain(new MdrDataElement(uri)); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrDataElement(uri)); 
	} 

	public Set<MdrCompositeInformationItem> isComponentOfMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrCompositeInformationItemDAO(client).findMdrCompositeInformationItemByComposedOf(new MdrDataElement(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrDataElement(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasSource(new MdrDataElement(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasPossibleSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasPossibleSource(new MdrDataElement(uri)); 
	} 

	public Set<MdrMappableRelationshipItem> hasTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMappableRelationshipItemDAO(client).findMdrMappableRelationshipItemByHasTarget(new MdrDataElement(uri)); 
	} 

}
