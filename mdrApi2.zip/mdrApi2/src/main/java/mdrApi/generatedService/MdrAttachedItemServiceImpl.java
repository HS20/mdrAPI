package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrAttachedItemServiceImpl extends MdrRegisteredItemServiceImpl implements MdrAttachedItemService {
	protected static final Logger log = Logger.getLogger(MdrAttachedItemServiceImpl.class);

	public MdrAttachedItemServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrAttachedItem readMdrAttachedItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrAttachedItemDAO(client).readMdrAttachedItem(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrAttachedItem(uri)); 
	} 

	public Set<MdrAdministeredItem> attachedToAttachmentMdrAdministeredItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrAdministeredItemDAO(client).findMdrAdministeredItemByInverseAttachedToAttachment(new MdrAttachedItem(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrAttachedItem(uri)); 
	} 

}
