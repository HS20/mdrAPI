package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import mdrApi.generatedDomain.MdrDataElementConcept;
import mdrApi.generatedDomain.MdrValueDomain;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;

public interface MdrDataElementService extends MdrThingService {






 MdrDataElement readMdrDataElement(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDataElementConcept> representsDataElementMeaningMdrDataElementConcept(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasPossibleTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrValueDomain> usesDataElementDomainMdrValueDomain(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrCompositeInformationItem> isComponentOfMdrCompositeInformationItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasPossibleSourceMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

 Set<MdrMappableRelationshipItem> hasTargetMdrMappableRelationshipItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
