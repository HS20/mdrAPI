package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrAdministeredItemDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDAO.MdrAttachedItemDAO;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrAdministeredItem;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import mdrApi.generatedDomain.MdrAttachedItem;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrAdministeredItemServiceImpl extends MdrRegisteredItemServiceImpl implements MdrAdministeredItemService {
	protected static final Logger log = Logger.getLogger(MdrAdministeredItemServiceImpl.class);

	public MdrAdministeredItemServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrAdministeredItem readMdrAdministeredItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrAdministeredItemDAO(client).readMdrAdministeredItem(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrAdministeredItem(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByUsedForItemItemDesignation(new MdrAdministeredItem(uri)); 
	} 

}
