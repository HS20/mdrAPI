package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDAO.MdrContextDAO;
import mdrApi.generatedDAO.MdrDesignationDAO;
import mdrApi.generatedDAO.MdrMetadatatItemDAO;
import mdrApi.generatedDAO.MdrDefinitionDAO;
import mdrApi.generatedDomain.MdrContext;
import mdrApi.generatedDomain.MdrDesignation;
import mdrApi.generatedDomain.MdrMetadatatItem;
import mdrApi.generatedDomain.MdrDefinition;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import java.util.Set;

public class MdrDesignationServiceImpl extends MdrMetadatatItemServiceImpl implements MdrDesignationService {
	protected static final Logger log = Logger.getLogger(MdrDesignationServiceImpl.class);

	public MdrDesignationServiceImpl(BlazeGraphClient client) {
		super(client);

	}




	public MdrDesignation readMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).readMdrDesignation(uri); 
	} 

	public Set<MdrDefinition> hasDefinitionItemDefinitionMdrDefinition(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDefinitionDAO(client).findMdrDefinitionByUsedForItemItemDefinition(new MdrDesignation(uri)); 
	} 

	public Set<MdrDesignation> hasDesignationItemDesignationMdrDesignation(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrDesignationDAO(client).findMdrDesignationByHasDesignationItemDesignation(new MdrDesignation(uri)); 
	} 

	public Set<MdrMetadatatItem> usedForItemItemDesignationMdrMetadatatItem(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrMetadatatItemDAO(client).findMdrMetadatatItemByHasDesignationItemDesignation(new MdrDesignation(uri)); 
	} 

	public Set<MdrContext> occursInScopeDesignationContextMdrContext(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrContextDAO(client).findMdrContextByIncludesRelevantDesignationDesignationContext(new MdrDesignation(uri)); 
	} 

}
