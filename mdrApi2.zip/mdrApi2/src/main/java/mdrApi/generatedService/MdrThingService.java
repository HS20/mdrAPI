package mdrApi.generatedService;


import mdrApi.generatedDomain.MdrThing;
import java.lang.reflect.InvocationTargetException;

public interface MdrThingService {






 MdrThing readMdrThing(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException;

}
