package mdrApi.generatedService;


import org.apache.log4j.Logger;
import mdrApi.generatedDomain.MdrThing;
import mdrApi.generatedDAO.MdrThingDAO;
import java.lang.reflect.InvocationTargetException;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;

public class MdrThingServiceImpl implements MdrThingService {
	protected static final Logger log = Logger.getLogger(MdrThingServiceImpl.class);
	protected BlazeGraphClient client;

	public MdrThingServiceImpl(BlazeGraphClient client) {
		this.client=client;

	}




	public MdrThing readMdrThing(String uri) throws IllegalArgumentException ,InvocationTargetException ,IllegalAccessException {		return  new MdrThingDAO(client).readMdrThing(uri); 
	} 

}
