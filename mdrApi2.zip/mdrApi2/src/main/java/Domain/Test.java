package Domain;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.util.ModelBuilder;

import Bean.CoupleDEPV;
import chu_bordeaux.org.ClientRDF4J.BlazeGraphClient;
import generateJavaClass.service.IRIManager;
import mdrApi.Service.codeValueManager;
import mdrApi.generatedDAO.MdrCompositeInformationItemDAO;
import mdrApi.generatedDAO.MdrDataElementDAO;
import mdrApi.generatedDAO.MdrPermissibleValueDAO;
import mdrApi.generatedDomain.MdrCompositeInformationItem;
import mdrApi.generatedDomain.MdrDataElement;
import mdrApi.generatedDomain.MdrMappableRelationshipItem;
import mdrApi.generatedDomain.MdrPermissibleValue;
import mdrApi.generatedService.MdrCompositeInformationItemService;
import mdrApi.generatedVocabulary.MDRVOCABULARY;



public class Test {
	
	private static final String Static = null;

	public static String jdbcUrl = "jdbc:oracle:thin:@siad01:1529:INFOPAT";
	public static  String USER = "i2b2demodata";
	public static  String PASS = "i2b2demodata_ucaim";
	private static int i =0;
	public static  Connection connection = null;
	public static Statement stmt = null;
	// public static ResultSet rs;
	// Database credentials
	
	
	
	public Test() {

	}
	
	public static void jdbcload() {
		try {
			// The newInstance() call is a work around for some
			// broken Java implementations

			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		} catch (Exception ex) {
			// handle the error
		}
	}
	
	// methode connection 
	
	public static  boolean jdbcConnect() {
		try {
			
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(jdbcUrl, USER , PASS);

			// Do something with the Connection

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			return false;
		}
		
		if (connection != null) {
          System.out.println("You made it, take control your database now!");
     } else {
          System.out.println("Failed to make connection!");
     }
return true;
}
	
	// R�cup�ration des couple DE/PV  � partir des PV i2b2
	
	public Set<CoupleDEPV> CoupleDEPV(Set<CoupleDEPV> CoupleDEPV1) throws SQLException {
		Set<CoupleDEPV> CoupleDEPV=new HashSet<CoupleDEPV>();
		jdbcConnect();
		Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
		ResultSet.CONCUR_READ_ONLY);
		
		String sqlNiref = "select Concept_cd,Niq from IAM.I2B2_DXC_PERMISSIBLE f ";	
		ResultSet res = stmt.executeQuery(sqlNiref);
		stmt.setMaxRows(20);
	
		Set <CoupleDEPV> CoupleDEPV11 = new HashSet<CoupleDEPV>();
		Set <CoupleDEPV> CoupleDEPV12 = new HashSet<CoupleDEPV>();
		while (res.next()) {
		CoupleDEPV coupleDEPV = new CoupleDEPV(res.getString("NIQ"),res.getString("CONCEPT_CD"));
		System.out.println ("niq"+(res.getString("NIQ")+"concept_cd"+res.getString("CONCEPT_CD")));
		CoupleDEPV11.add(coupleDEPV);
		}
		
		for (CoupleDEPV coupledepv : CoupleDEPV11) {
		System.out.println (coupledepv.getNiq()+coupledepv.getNiref());
		String sqlVD = "select distinct ID_Dataelement,type_valuedomain  from IAM.i2b2_dataelement f where f.id_dataelement like 'DXC|QUESTION:"+coupledepv.getNiq()+"' ";	
		System.out.println(sqlVD);
		ResultSet rs = stmt.executeQuery(sqlVD);
		
		while (rs.next()) {
			if (rs.getString("id_dataelement") != null && !rs.getString("id_dataelement").isEmpty()) {
				CoupleDEPV coupledepv1 = new CoupleDEPV(coupledepv.getNiq(),coupledepv.getNiref());
			System.out.println (rs.getString("id_dataelement"));
			System.out.println (rs.getString("type_valuedomain"));
			//System.out.println(coupledepv1.getNiq()+coupledepv1.getNiref());
			CoupleDEPV1.add(coupledepv1);
			}
	}}
//	for (CoupleDEPV coupleDEPV1 :CoupleDEPV) {
//			String DataElement = "select d.ID_DATAELEMENT, p.ID_PERMISSIBLEVALUE from iam.i2b2_DATAELEMENT d inner join iam.i2b2_permissiblevalue p on d.ID_VALUEDOMAIN = p.ID_VALUEDOMAIN\r\n" + 
//			"where p.ID_PERMISSIBLEVALUE like 'DXC|REPONSE:"+coupleDEPV1.getNiref()+"%' and d.ID_DATAELEMENT like '%"+coupleDEPV1.getNiq()+"%'";
//			//System.out.println (pv.getPermV());
//			//System.out.println (DataElement);
//			ResultSet resDEPV = stmt.executeQuery(DataElement);
//			while (resDEPV.next()){
//				CoupleDEPV coupleDEPV2 = new CoupleDEPV(resDEPV.getString("ID_DATAELEMENT"),resDEPV.getString("ID_PERMISSIBLEVALUE"));
//				CoupleDEPV1.add(coupleDEPV2);
//				System.out.println(resDEPV.getString("ID_DATAELEMENT")+resDEPV.getString("ID_PERMISSIBLEVALUE"));
//			}
//		};	
	
	return CoupleDEPV1;
	}
	
	public static void linkingPV12b2toSource () throws MalformedURLException, IllegalArgumentException, InvocationTargetException, IllegalAccessException{
		
		String endPoint=new URL("http", "sim1dev", 8889, "/bigdata").toExternalForm();
		String namespace="mdrHadrien";
		BlazeGraphClient client = new BlazeGraphClient(endPoint, namespace,false);
	
		StringBuilder sb=new StringBuilder();
	sb.append(" ?VD <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#hasMemberPermissibleValueSet> ?uri.\r\n");
	sb.append("	?DE <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usesDataElementDomain> ?VD.\r\n");
	sb.append("	?DE  <http://www.w3.org/2000/01/rdf-schema#label>  ?l.\r\n" + 
			"   ?l bds:search \"CONCEPT_CD\";"
			+ "	bds:matchAllTerms \"true\".");


	
//	 Relation source/target i2b2/CII
	new MdrPermissibleValueDAO(client).readAllMdrPermissibleValue(sb).forEach(p -> {
//		System.out.println(p.getUri());
//		System.out.println(p.getLabel());	
//		System.out.println(p.getPermittedValue());
		Set<String> PVi2b2 = p.getPermittedValue();
		PVi2b2.forEach( a ->{
		String DE = new codeValueManager().deCodeCode(a).get("idDataElement");
//		System.out.println("data " + new codeValueManager().deCodeCode(a).get("idDataElement"));
//		System.out.println("prefix " +new codeValueManager().deCodeCode(a).get("prefix"));
		String PmV = new codeValueManager().deCodeCode(a).get("idPermissible");
//		System.out.println("perm " +new codeValueManager().deCodeCode(a).get("idPermissible")); 
		if (PmV!=null)
		{	
			MdrCompositeInformationItem CII = new MdrCompositeInformationItem("http://chu-bordeaux.fr/mdr/i2b2",
			DE+PmV,true);	
			new MdrCompositeInformationItemDAO(client).write(CII, "http://testHadrien#");
			MdrDataElement DataElement = new MdrDataElement("http://chu-bordeaux.fr/mdr/chubdx",DE,true);		
			new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, DataElement, "http://testHadrien#2");
			MdrPermissibleValue PV = new MdrPermissibleValue("http://chu-bordeaux.fr/mdr/chubdx",PmV,true);
			new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, PV, "http://testHadrien#2");
			new MdrCompositeInformationItemDAO(client).writeHasPossibleSource(p, CII, "http://testHadrien#2");
		
		}
		else if (PmV==null)
		{
			MdrDataElement DataElement = new MdrDataElement("http://chu-bordeaux.fr/mdr/chubdx",DE,true);		
			new MdrPermissibleValueDAO(client).writeHasPossibleSource(p, DataElement,"http://testHadrien#2");
			System.out.println("de : " + DataElement.getUri());
//			System.out.println("pv : " + p.getUri());
		}
		
		});
	
	
});
	
	client.close();
		
	}
	
	
	
	
	
	
	public static void main(String[] args) throws SQLException, IllegalArgumentException, InvocationTargetException, IllegalAccessException, MalformedURLException {
		String endPoint=new URL("http", "sim1dev", 8889, "/bigdata").toExternalForm();
		String namespace="mdrHadrien";
		BlazeGraphClient client = new BlazeGraphClient(endPoint, namespace,false);
				
		
		
		Test.linkingPV12b2toSource();
		
		
		// test requ�te Couple DEPV
		//SqlQuery CoupleDEPV = new SqlQuery();
		
		Set<CoupleDEPV> CoupleDEPV1 = new HashSet <CoupleDEPV>();
		//CoupleDEPV.CoupleDEPV( CoupleDEPV1);
//		for (CoupleDEPV coupledepv :CoupleDEPV1) {
//			
//			ModelBuilder builder = new ModelBuilder();
//			builder.namedGraph("http://testGraph");
//			System.out.println(coupledepv.getNiq());
//			
//			// decoupe PV i2b2 
//			String[] PVi2b2 = coupledepv.getNiref().split("-");
//			String rep = PVi2b2[1];
//			System.out.println(rep);
//			MdrCompositeInformationItem CII = new MdrCompositeInformationItem("http://chu-bordeaux.fr/mdr/i2b2",
//					"DXC|QUESTION:"+coupledepv.getNiq()+"DXC|REPONSE:"+rep,true);
//			
//			
//			// Recupere DataElement
//			
//			MdrDataElement DE = new MdrDataElement("http://chu-bordeaux.fr/mdr/chubdx","DXC|QUESTION:"+coupledepv.getNiq(),true);		
//			new MdrCompositeInformationItemDAO(client).addToBuilderComposedOf(CII, DE, builder);
//			new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, DE, "http://testHadrien#");
//			
////			
////			StringBuilder de=new StringBuilder();
////			de.append("	?uri <http://www.w3.org/2000/01/rdf-schema#comment> ?l.\n");
////			de.append("	?l bds:search \"Id : DXC|QUESTION:"+coupledepv.getNiq()+"\";\n");
////			de.append("		bds:matchAllTerms \"true\" ;\n");
////			de.append("		bds:minRelevance \"1\" . \n");
////			
////			new MdrDataElementDAO(client).readAllMdrDataElement(de).forEach(a -> {
////			//ajout pv au composite
////				
////
////				new MdrCompositeInformationItemDAO(client).addToBuilderComposedOf(CII, a, builder);
////				new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, a, "http://testHadrien#");
//////				System.out.println(a.getUri());
////				a.getLabel().stream().forEach(b -> {
////					System.out.println(b);
////				});
////				a.getType().stream().forEach(c -> {
////					System.out.println(c.getLocalName());
////				});				
////			});;
//			
//			// recupere PV
//
//			MdrPermissibleValue PV = new MdrPermissibleValue("http://chu-bordeaux.fr/mdr/chubdx","DXC|REPONSE:"+rep,true);
//			new MdrCompositeInformationItemDAO(client).addToBuilderComposedOf(CII, PV, builder);
//			new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, PV, "http://testHadrien#");
//			
//			
////			
////			StringBuilder pv=new StringBuilder();
////			pv.append("	?uri <http://www.w3.org/2000/01/rdf-schema#comment> ?l.\n");
////			pv.append("	?l bds:search \"Id : DXC|REPONSE:"+rep+"\";\n");
////			pv.append("		bds:matchAllTerms \"true\" ;\n");
////			pv.append("		bds:relevance ?score . \n");
////			
////			new MdrPermissibleValueDAO(client).readAllMdrPermissibleValue(pv).forEach(d -> {
////			// ajout pv au composite
////			
////				
////				new MdrCompositeInformationItemDAO(client).addToBuilderComposedOf(CII, d, builder);
////				new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, d, "http://testHadrien#");
//////				System.out.println(d.getUri());
//////				d.getLabel().stream().forEach(e -> {
//////					System.out.println(e);
//////				});
//////				d.getType().stream().forEach(f -> {
//////					System.out.println(f.getLocalName());
//////				});
////			});;
//						
//			// recupere PV i2b2
//			
//			MdrPermissibleValue PV1 = new MdrPermissibleValue("http://chu-bordeaux.fr/mdr/i2b2",coupledepv.getNiref(),true);
//			new MdrCompositeInformationItemDAO(client).addToBuilderHasPossibleSource(PV1, CII, builder);
//			new MdrCompositeInformationItemDAO(client).writeHasPossibleSource(PV1, CII, "http://testHadrien#");
//			
//			
////			StringBuilder sb=new StringBuilder();
////			sb.append("	?uri <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#permittedValue> ?permittedValue . ");
////			sb.append("	?permittedValue bds:search \""+coupledepv.getNiref()+"\" ;\n");
////			sb.append("		bds:matchAllTerms \"true\" ;\n");
////			//sb.append("		bds:minRelevance \"1\" . \n");
////			sb.append("		bds:relevance ?score . \n");
////			
////			// Relation source/target i2b2/CII
////			new MdrPermissibleValueDAO(client).readAllMdrPermissibleValue(sb).forEach(p -> {
////							
////				new MdrCompositeInformationItemDAO(client).addToBuilderHasPossibleSource(p, CII, builder);
////				new MdrCompositeInformationItemDAO(client).writeHasPossibleSource(p, CII, "http://testHadrien#");
////				System.out.println(p.getUri());
////				p.getLabel().stream().forEach(l -> {
////					System.out.println(l);
////				});
////					p.getType().stream().forEach(t -> {
////					System.out.println(t.getLocalName());
////				});
////			});;
//			
//		
//			new MdrCompositeInformationItemDAO(client).write(CII, "http://testHadrien#");
//				
//			
//			// Composition CompositeInformationItem
////			ModelBuilder builder = new ModelBuilder();
////			builder.namedGraph("http://testGraph");
////			MdrCompositeInformationItem CII = new MdrCompositeInformationItem("http://chu-bordeaux.fr/mdr/i2b2",
////					"DXC|QUESTION:"+coupledepv.getNiq()+"DXC|REPONSE:"+coupledepv.getNiref(),true);
////			new MdrCompositeInformationItemDAO(client).addToBuilderComposedOf(CII, de, builder);	
//		}
//		
//		new MdrCompositeInformationItemDAO(client).readAllMdrCompositeInformationItem().forEach(p -> {
//			System.out.println(p.getUri());});
//		
//			

	


		
		//// Creation CII � partir de Couple DE/PV
		
		
		//MdrCompositeInformationItem CII = new MdrCompositeInformationItem("http://testCII"+s);
		//System.out.println (MDRVOCABULARY.CompositeInformationItemStr);
		
		
		//// Recup i2b2value puis codedecode
	//	client.getRdf4jClient().deleteGraph("http://testHadrien#");
		
//		MdrPermissibleValue permV=new MdrPermissibleValue("http://testCompositePermV");
//		permV.addLabel("test Composite PermV");
//		new MdrPermissibleValueDAO(client).write(permV);
		
//		new MdrCompositeInformationItemDAO(client).readAllMdrCompositeInformationItem().forEach(p -> {
//			System.out.println("Composite : " + p.getUri());
//			try {
//				new MdrDataElementDAO(client).findMdrDataElementByIsComponentOf(p).forEach(d -> {
//					System.out.println("dataElement : "  + d.getUri());
//					d.getLabel().forEach(l -> {
//						System.out.println(l);
//					});
//				});
//			} catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			try {
//				new MdrPermissibleValueDAO(client).findMdrPermissibleValueByIsComponentOf(p).forEach(v -> {
//					System.out.println("permissible : "  + v.getUri());
//					v.getLabel().forEach(la -> {
//						System.out.println(la);
//					});
//				});
//			} catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		
//		});
//		new MdrDataElementDAO(client).readAllMdrDataElement().forEach (d ->{
//			try {
//				new MdrPermissibleValueDAO(client).findMdrPermissibleValueByHasPossibleSource(d);
//			} catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println("PV : "  + d.getUri());
//		});
//	
		
//		
//		StringBuilder sb=new StringBuilder();
//	sb.append(" ?VD <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#hasMemberPermissibleValueSet> ?uri.\r\n");
//	sb.append("	?DE <http://chu-bordeaux.fr/m2sitis/iso11179-3/mdr.owl#usesDataElementDomain> ?VD.\r\n");
//	sb.append("	?DE  <http://www.w3.org/2000/01/rdf-schema#label>  ?l.\r\n" + 
//			"   ?l bds:search \"CONCEPT_CD\";"
//			+ "	bds:matchAllTerms \"true\".");
//
////	client.getRdf4jClient().deleteGraph("http://testHadrien#");
//	
////	 Relation source/target i2b2/CII
//	new MdrPermissibleValueDAO(client).readAllMdrPermissibleValue(sb).forEach(p -> {
////		System.out.println(p.getUri());
////		System.out.println(p.getLabel());	
////		System.out.println(p.getPermittedValue());
//		Set<String> PVi2b2 = p.getPermittedValue();
//		PVi2b2.forEach( a ->{
//		String DE = new codeValueManager().deCodeCode(a).get("idDataElement");
////		System.out.println("data " + new codeValueManager().deCodeCode(a).get("idDataElement"));
////		System.out.println("prefix " +new codeValueManager().deCodeCode(a).get("prefix"));
//		String PmV = new codeValueManager().deCodeCode(a).get("idPermissible");
////		System.out.println("perm " +new codeValueManager().deCodeCode(a).get("idPermissible")); 
//		if (PmV!=null)
//		{	
//			MdrCompositeInformationItem CII = new MdrCompositeInformationItem("http://chu-bordeaux.fr/mdr/i2b2",
//			DE+PmV,true);	
//			new MdrCompositeInformationItemDAO(client).write(CII, "http://testHadrien#");
//			MdrDataElement DataElement = new MdrDataElement("http://chu-bordeaux.fr/mdr/chubdx",DE,true);		
//			new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, DataElement, "http://testHadrien#2");
//			MdrPermissibleValue PV = new MdrPermissibleValue("http://chu-bordeaux.fr/mdr/chubdx",PmV,true);
//			new MdrCompositeInformationItemDAO(client).writeComposedOf(CII, PV, "http://testHadrien#2");
//			new MdrCompositeInformationItemDAO(client).writeHasPossibleSource(p, CII, "http://testHadrien#2");
//		
//		}
//		else if (PmV==null)
//		{
//			MdrDataElement DataElement = new MdrDataElement("http://chu-bordeaux.fr/mdr/chubdx",DE,true);		
//			new MdrPermissibleValueDAO(client).writeHasPossibleSource(p, DataElement,"http://testHadrien#2");
////			System.out.println("de : " + DataElement.getUri());
////			System.out.println("pv : " + p.getUri());
//		}
//		
//		});
//	
//	
//});
//	
//	client.close();
}
	
}
















