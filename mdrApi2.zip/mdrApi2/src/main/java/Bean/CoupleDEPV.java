package Bean;

public class CoupleDEPV {

		private String niref;
		private String niq;
		public CoupleDEPV (String niq,String niref) {
			setNiref(niref);
			setNiq(niq);
		}
		public String getNiref() {
			return niref;
		}
		public void setNiref(String niref) {
			this.niref = niref;
		}
		public String getNiq() {
			return niq;
		}
		public void setNiq(String niq) {
			this.niq = niq;
		}

		
}
